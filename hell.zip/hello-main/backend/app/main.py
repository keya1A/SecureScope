from __future__ import annotations

import ipaddress
import json
import os
import re
import shutil
import socket
import ssl
import subprocess
import time
import uuid
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

import dns.resolver
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from supabase import create_client, Client

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL", "").strip()
SUPABASE_SERVICE_ROLE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "").strip()
FRONTEND_ORIGINS = [
    item.strip()
    for item in os.getenv("FRONTEND_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")
    if item.strip()
]
SCAN_TIMEOUT_SECONDS = int(os.getenv("SCAN_TIMEOUT_SECONDS", "180"))
MAX_CONCURRENT_SCANS = int(os.getenv("MAX_CONCURRENT_SCANS", "1"))

if not SUPABASE_URL or not SUPABASE_SERVICE_ROLE_KEY:
    raise RuntimeError(
        "Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in backend/.env before starting the API."
    )

supabase: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

app = FastAPI(title="SecureScope Local Scan API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=FRONTEND_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)

class ScanRequest(BaseModel):
    domain: str = Field(min_length=3, max_length=253)
    authorized: bool

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def validate_public_domain(value: str) -> tuple[str, list[str]]:
    raw = value.strip().lower()
    if "://" in raw:
        parsed = urlparse(raw)
        if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.path not in ("", "/"):
            raise HTTPException(400, "Enter a hostname only, such as example.com.")
        raw = parsed.hostname
    raw = raw.rstrip(".")
    if not raw or len(raw) > 253 or not re.fullmatch(r"(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(\.([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))+", raw):
        raise HTTPException(400, "Enter a valid public DNS hostname, such as example.com.")
    try:
        answers = socket.getaddrinfo(raw, None, type=socket.SOCK_STREAM)
        ips = sorted({item[4][0] for item in answers})
    except socket.gaierror:
        raise HTTPException(422, "The target hostname did not resolve.")
    if not ips:
        raise HTTPException(422, "The target hostname did not resolve.")
    for item in ips:
        ip = ipaddress.ip_address(item)
        if not ip.is_global:
            raise HTTPException(400, "Private, loopback, link-local, and reserved IP addresses are blocked.")
    return raw, ips

def run_command(args: list[str], timeout: int) -> tuple[str, str, int | None, str | None]:
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
            shell=False,
            encoding="utf-8",
            errors="replace",
        )
        return result.stdout[:2_000_000], result.stderr[:20_000], result.returncode, None
    except subprocess.TimeoutExpired:
        return "", "Command timed out.", None, "timeout"
    except OSError as exc:
        return "", str(exc), None, "execution_error"

def dns_snapshot(domain: str) -> tuple[dict[str, list[str]], dict[str, Any]]:
    records: dict[str, list[str]] = {key: [] for key in ["A", "AAAA", "CNAME", "MX", "NS", "TXT", "SOA", "CAA"]}
    resolver = dns.resolver.Resolver()
    resolver.lifetime = 5
    for kind in records:
        try:
            answers = resolver.resolve(domain, kind, raise_on_no_answer=False)
            if answers.rrset:
                records[kind] = [str(item).strip('"') for item in answers]
        except Exception:
            pass
    txt = records["TXT"]
    spf_record = next((item for item in txt if item.lower().startswith("v=spf1")), None)
    try:
        dmarc_answers = resolver.resolve(f"_dmarc.{domain}", "TXT")
        dmarc_record = next((str(item).strip('"') for item in dmarc_answers if "v=dmarc1" in str(item).lower()), None)
    except Exception:
        dmarc_record = None
    dkim_selectors = []
    for selector in ["default", "selector1", "selector2", "google", "k1"]:
        try:
            resolver.resolve(f"{selector}._domainkey.{domain}", "TXT")
            dkim_selectors.append(selector)
        except Exception:
            pass
    return records, {
        "spf": {"present": bool(spf_record), "record": spf_record, "policy": spf_record.split()[-1] if spf_record else None},
        "dmarc": {"present": bool(dmarc_record), "record": dmarc_record, "policy": next((p.split("=",1)[1] for p in dmarc_record.split(";") if p.strip().lower().startswith("p=")), None) if dmarc_record else None},
        "dkim": {"discovered": bool(dkim_selectors), "selectors": dkim_selectors},
        "dnssec": "unsigned",
    }

def http_snapshot(domain: str) -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    import urllib.request
    import urllib.error

    url = f"https://{domain}/"
    headers: dict[str, str] = {}
    status = None
    final_url = None
    set_cookie_headers: list[str] = []
    reachable = False
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "SecureScope-Authorized-Assessment/1.0"}, method="GET")
        with urllib.request.urlopen(request, timeout=12) as response:
            status = response.status
            final_url = response.geturl()
            headers = {k.lower(): v for k, v in response.headers.items()}
            set_cookie_headers = response.headers.get_all("Set-Cookie") or []
            reachable = True
    except urllib.error.HTTPError as exc:
        status = exc.code
        final_url = exc.geturl()
        headers = {k.lower(): v for k, v in exc.headers.items()}
        set_cookie_headers = exc.headers.get_all("Set-Cookie") or []
        reachable = True
    except Exception:
        pass

    checks = []
    recommendations = {
        "strict-transport-security": "Enable HSTS with an appropriate max-age after confirming HTTPS works.",
        "content-security-policy": "Define a Content-Security-Policy appropriate for the application.",
        "x-content-type-options": "Set X-Content-Type-Options: nosniff.",
        "x-frame-options": "Set X-Frame-Options or an appropriate frame-ancestors CSP directive.",
        "referrer-policy": "Set a restrictive Referrer-Policy.",
        "permissions-policy": "Define a Permissions-Policy for browser capabilities.",
    }
    for name, advice in recommendations.items():
        value = headers.get(name)
        checks.append({
            "name": name,
            "present": bool(value),
            "value": value,
            "status": "secure" if value else "missing",
            "impact": f"{name} is {'present' if value else 'not present'} in the response.",
            "recommendation": advice,
        })
    cookies = []
    for raw in set_cookie_headers:
        parts = [part.strip() for part in raw.split(";")]
        cookies.append({
            "name": parts[0].split("=", 1)[0] if parts else "unknown",
            "secure": any(p.lower() == "secure" for p in parts[1:]),
            "httpOnly": any(p.lower() == "httponly" for p in parts[1:]),
            "sameSite": next((p.split("=",1)[1] for p in parts[1:] if p.lower().startswith("samesite=")), None),
        })
    http = {
        "reachable": reachable,
        "finalUrl": final_url,
        "statusCode": status,
        "httpRedirectsToHttps": None,
        "headers": checks,
        "cookies": cookies,
        "serverBanner": headers.get("server"),
        "poweredBy": headers.get("x-powered-by"),
    }
    tls = {
        "source": "Python TLS socket",
        "found": False,
        "subject": None,
        "issuer": None,
        "validFrom": None,
        "validUntil": None,
        "daysRemaining": None,
        "status": "unknown",
        "chainValid": None,
        "tlsVersion": None,
        "note": "TLS details were not available.",
    }
    try:
        context = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=8) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as tls_sock:
                cert = tls_sock.getpeercert()
                tls["found"] = True
                tls["chainValid"] = True
                tls["tlsVersion"] = tls_sock.version()
                tls["subject"] = ", ".join("=".join(x) for group in cert.get("subject", []) for x in group)
                tls["issuer"] = ", ".join("=".join(x) for group in cert.get("issuer", []) for x in group)
                tls["validFrom"] = cert.get("notBefore")
                tls["validUntil"] = cert.get("notAfter")
                if cert.get("notAfter"):
                    expires = datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                    days = (expires - datetime.now(timezone.utc)).days
                    tls["daysRemaining"] = days
                    tls["status"] = "expired" if days < 0 else ("expiring" if days <= 30 else "valid")
                tls["note"] = "Certificate retrieved and verified using the system trust store."
    except Exception as exc:
        tls["note"] = f"TLS inspection failed: {str(exc)[:180]}"
        tls["chainValid"] = False
    return http, tls, checks

def parse_json_lines(output: str) -> list[dict[str, Any]]:
    items = []
    for line in output.splitlines():
        try:
            value = json.loads(line)
            if isinstance(value, dict):
                items.append(value)
        except json.JSONDecodeError:
            continue
    return items

def severity_name(value: str) -> str:
    v = value.lower()
    if v in ("critical", "high", "medium", "low"):
        return v.capitalize()
    return "Informational"

def build_result(domain: str, started: float, dns_records: dict[str, list[str]], dns_security: dict[str, Any],
                 http: dict[str, Any], tls: dict[str, Any], tool_data: dict[str, Any]) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    modules = []
    logs = []
    def log(module: str, level: str, message: str):
        logs.append({"time": now_iso(), "module": module, "level": level, "message": message})
    def module(mid: str, label: str, status: str, message: str, duration: int = 0):
        modules.append({"id": mid, "label": label, "status": status, "message": message, "durationMs": duration})
        log(mid, "error" if status == "error" else ("warn" if status == "warning" else "info"), message)

    module("validation", "Domain Validation", "ok", f"{domain} passed public-host validation.")
    module("dns", "DNS Analysis", "warning" if not dns_security["spf"]["present"] or not dns_security["dmarc"]["present"] else "ok",
           f"Resolved {len(dns_records['A']) + len(dns_records['AAAA'])} address record(s).")
    module("http", "HTTP Header Analysis", "ok" if http["reachable"] else "warning",
           f"HTTPS {'responded with HTTP ' + str(http['statusCode']) if http['reachable'] else 'could not be reached'}; {sum(1 for h in http['headers'] if not h['present'])} recommended header(s) missing.")
    module("tls", "SSL/TLS Analysis", "ok" if tls["status"] == "valid" else "warning", tls["note"])
    module("whois", "WHOIS Lookup", "warning", "WHOIS enrichment is not configured in this local FastAPI backend.")
    module("technology", "Technology Detection", "ok" if tool_data["httpx"]["items"] else "warning",
           f"httpx returned {len(tool_data['httpx']['items'])} result record(s).")
    module("cve", "CVE Correlation", "warning", "CVE correlation is not configured; scanner templates are not a verified CVE inventory.")
    for header in http["headers"]:
        if not header["present"]:
            findings.append({
                "id": str(uuid.uuid4()), "title": f"Missing {header['name']} header", "severity": "Low",
                "module": "http", "asset": f"https://{domain}/", "description": header["impact"],
                "evidence": f"Response did not include {header['name']}.", "impact": header["impact"],
                "remediation": header["recommendation"], "confidence": "Confirmed", "cveId": None
            })
    for item in tool_data["nuclei"]["items"]:
        info = item.get("info") or {}
        name = info.get("name") or item.get("template-id") or "Nuclei finding"
        sev = severity_name(str(info.get("severity", "info")))
        matched = item.get("matched-at") or item.get("host") or f"https://{domain}/"
        findings.append({
            "id": str(uuid.uuid4()), "title": str(name)[:180], "severity": sev, "module": "findings",
            "asset": str(matched)[:500], "description": str(info.get("description") or "Reported by a Nuclei template.")[:2000],
            "evidence": json.dumps(item, ensure_ascii=False)[:4000],
            "impact": "Review the matched template and reproduce safely to determine actual exposure.",
            "remediation": str(info.get("remediation") or "Review the affected component and apply the vendor-recommended fix.")[:1500],
            "confidence": "Likely", "cveId": next((t for t in info.get("classification", {}).get("cve-id", []) if isinstance(t, str)), None)
        })
    for item in tool_data["nikto"]["items"]:
        msg = str(item.get("msg") or item.get("message") or item.get("description") or item)[:500]
        findings.append({
            "id": str(uuid.uuid4()), "title": "Nikto web server observation", "severity": "Informational",
            "module": "findings", "asset": f"https://{domain}/", "description": msg,
            "evidence": json.dumps(item, ensure_ascii=False)[:3000],
            "impact": "This is a scanner observation and is not necessarily a vulnerability.",
            "remediation": "Manually validate the observation and follow the relevant vendor hardening guidance.",
            "confidence": "Inferred", "cveId": None
        })
    module("findings", "Security Findings", "ok", f"{len(findings)} observation(s) assembled.")
    score_weights = {"Critical": 25, "High": 15, "Medium": 8, "Low": 3, "Informational": 0}
    score = min(100, sum(score_weights.get(f["severity"], 0) for f in findings))
    category = "Critical" if score >= 75 else "High" if score >= 50 else "Medium" if score >= 25 else "Low"
    module("risk", "Risk Scoring", "ok", f"Calculated provisional score {score}/100 ({category}).")
    module("report", "Report Generation", "ok", "Assessment payload assembled.")
    duration = int((time.time() - started) * 1000)
    return {
        "domain": domain, "scannedAt": now_iso(), "durationMs": duration,
        "modules": modules, "log": logs, "http": http, "tls": tls,
        "dns": {"records": dns_records, "security": dns_security},
        "whois": {"available": False, "registrar": None, "registeredOn": None, "expiresOn": None,
                  "ageDays": None, "daysUntilExpiry": None, "nameServers": dns_records["NS"],
                  "note": "WHOIS lookup is not configured."},
        "technologies": [], "cves": [], "cveNotes": ["CVE correlation is not configured in the local scanner."],
        "findings": findings,
        "risk": {"score": score, "category": category,
                 "factors": [{"label": "Scanner observations", "points": score, "maxPoints": 100,
                              "detail": "Provisional score based on collected observations; manually validate findings."}],
                 "summary": "Provisional automated assessment. Scanner observations require manual validation."}
    }

@app.get("/health")
def health():
    return {
        "status": "ok",
        "supabase_configured": bool(SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY),
        "tools": {name: shutil.which(name) is not None for name in ["nuclei", "httpx", "nikto"]},
    }

@app.post("/api/scan")
def scan(request: ScanRequest):
    if request.authorized is not True:
        raise HTTPException(400, "Confirm that you are authorized to assess this domain.")
    domain, resolved_ips = validate_public_domain(request.domain)
    started = time.time()
    records, dns_security = dns_snapshot(domain)
    # Re-resolve immediately before running external tools to reduce DNS-rebinding/target-change risk.
    _, current_ips = validate_public_domain(domain)
    if set(resolved_ips).isdisjoint(set(current_ips)):
        raise HTTPException(400, "The target DNS addresses changed during validation. Retry after checking the domain.")
    http, tls, _ = http_snapshot(domain)

    tools: dict[str, Any] = {
        "httpx": {"items": [], "error": None},
        "nuclei": {"items": [], "error": None},
        "nikto": {"items": [], "error": None},
    }
    if shutil.which("httpx"):
        out, err, code, issue = run_command(
            ["httpx", "-u", f"https://{domain}", "-json", "-silent", "-status-code", "-title",
             "-tech-detect", "-web-server", "-follow-redirects", "-timeout", "10", "-retries", "1",
             "-max-redirects", "3"], 35)
        tools["httpx"] = {"items": parse_json_lines(out), "error": issue or (err[:500] if code not in (0, None) else None)}
    else:
        tools["httpx"]["error"] = "ProjectDiscovery httpx binary was not found on PATH."
    if shutil.which("nuclei"):
        out, err, code, issue = run_command(
            ["nuclei", "-u", f"https://{domain}", "-jsonl", "-silent", "-no-color",
             "-tags", "misconfig,exposure,headers,ssl", "-severity", "info,low,medium,high,critical",
             "-rl", "3", "-c", "3", "-timeout", "5", "-retries", "0", "-disable-update-check"], 75)
        tools["nuclei"] = {"items": parse_json_lines(out), "error": issue or (err[:500] if code not in (0, None) else None)}
    else:
        tools["nuclei"]["error"] = "Nuclei binary was not found on PATH."
    if shutil.which("nikto"):
        out, err, code, issue = run_command(
            ["nikto", "-host", f"https://{domain}", "-Format", "json", "-output", "-", "-nointeractive"], 75)
        parsed = []
        try:
            value = json.loads(out) if out.strip() else {}
            if isinstance(value, dict):
                parsed = value.get("vulnerabilities") or value.get("items") or []
        except json.JSONDecodeError:
            parsed = [{"message": line.strip()} for line in out.splitlines() if line.strip() and not line.startswith("-")]
        tools["nikto"] = {"items": parsed[:100], "error": issue or (err[:500] if code not in (0, None) else None)}
    else:
        tools["nikto"]["error"] = "Nikto binary was not found on PATH."

    result = build_result(domain, started, records, dns_security, http, tls, tools)
    # Do not return raw scanner stderr; retain concise tool availability information in module logs.
    for name, info in tools.items():
        if info.get("error"):
            result["log"].append({"time": now_iso(), "module": "findings", "level": "warn",
                                  "message": f"{name}: {info['error']}"})
    try:
        saved = supabase.table("scans").insert({
            "domain": domain,
            "status": "completed",
            "risk_score": result["risk"]["score"],
            "risk_category": result["risk"]["category"],
            "result": result,
            "duration_ms": result["durationMs"],
            "created_at": result["scannedAt"],
        }).execute()
        row = saved.data[0] if saved.data else None
        if not row or not row.get("id"):
            raise RuntimeError("Supabase did not return the inserted scan ID.")
    except Exception as exc:
        raise HTTPException(502, f"Scan completed but saving to Supabase failed: {str(exc)[:240]}")
    return {"id": row["id"], "result": result}
