# SecureScope local FastAPI backend

## Requirements
- Python 3.10+
- ProjectDiscovery `httpx` binary
- Nuclei
- Nikto
- Supabase project with the existing `scans` migration applied

## Setup (PowerShell, from this folder)
```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and set `SUPABASE_URL` and the **service_role** key from Supabase Project Settings > API.
Never put the service-role key in a `VITE_` variable or frontend source code.

Install the scanner binaries separately and make sure `nuclei`, `httpx`, and `nikto` work from the same terminal:
```powershell
nuclei -version
httpx -version
nikto -Version
```

Start the API:
```powershell
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```
Open `http://127.0.0.1:8000/health` and `http://127.0.0.1:8000/docs`.

## Safety notes
Only scan systems you own or are explicitly authorized to assess. Nuclei and Nikto send active probes; the backend validates public DNS addresses and rejects private/reserved targets, but this is not a substitute for authorization or network-level egress controls. Run the local API only on loopback (`127.0.0.1`), not `0.0.0.0`.
