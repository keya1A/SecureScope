import { BACKEND_NOT_CONFIGURED_MESSAGE, supabase } from '@/lib/supabase';
import type { ScanResult, ScanRow } from '@/types/scan';

interface ScanResponse {
  id: string;
  result: ScanResult;
}

const LOCAL_SCAN_API = (import.meta.env.VITE_SCAN_API_URL as string | undefined)?.replace(/\/$/, '');

export async function runSecurityScan(domain: string): Promise<ScanResponse> {
  if (!LOCAL_SCAN_API) throw new Error(BACKEND_NOT_CONFIGURED_MESSAGE);
  let response: Response;
  try {
    response = await fetch(`${LOCAL_SCAN_API}/api/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain, authorized: true }),
    });
  } catch {
    throw new Error('Could not reach the local FastAPI scanner. Make sure it is running at http://127.0.0.1:8000.');
  }
  const body = (await response.json().catch(() => null)) as (Partial<ScanResponse> & { detail?: string; error?: string }) | null;
  if (!response.ok) throw new Error(body?.detail ?? body?.error ?? `The scan failed (HTTP ${response.status}).`);
  if (!body || typeof body.id !== 'string' || !body.result) {
    throw new Error('The scanning service returned an unexpected response.');
  }
  return { id: body.id, result: body.result };
}

function requireSupabase() {
  if (!supabase) throw new Error('Supabase is not configured. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in the frontend .env file.');
  return supabase;
}

export async function fetchScan(id: string): Promise<ScanRow | null> {
  const client = requireSupabase();
  const { data, error } = await client.from('scans').select('*').eq('id', id).maybeSingle();
  if (error) throw new Error(`Could not load this scan: ${error.message}`);
  return (data as ScanRow | null) ?? null;
}

export async function fetchRecentScans(limit = 50): Promise<ScanRow[]> {
  const client = requireSupabase();
  const { data, error } = await client
    .from('scans')
    .select('id, domain, status, risk_score, risk_category, result, duration_ms, created_at')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw new Error(`Could not load scan history: ${error.message}`);
  return (data ?? []) as ScanRow[];
}
