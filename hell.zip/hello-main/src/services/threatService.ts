import { BACKEND_NOT_CONFIGURED_MESSAGE, SUPABASE_ANON_KEY, supabase, THREAT_FUNCTION_URL } from '@/lib/supabase';
import type { ThreatFeed, ThreatLookupResult, ThreatLookupRow } from '@/types/threat';

async function callThreatFunction<T>(body: Record<string, unknown>): Promise<T> {
  if (!THREAT_FUNCTION_URL) throw new Error(BACKEND_NOT_CONFIGURED_MESSAGE);

  let response: Response;
  try {
    response = await fetch(THREAT_FUNCTION_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        apikey: SUPABASE_ANON_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });
  } catch {
    throw new Error('Could not reach the threat intelligence service. Check your connection and try again.');
  }

  const payload = (await response.json().catch(() => null)) as (T & { error?: string }) | null;
  if (!response.ok) {
    throw new Error(payload?.error ?? `The threat intelligence service failed (HTTP ${response.status}).`);
  }
  if (!payload) throw new Error('The threat intelligence service returned an unexpected response.');
  return payload;
}

export function fetchThreatFeed(): Promise<ThreatFeed> {
  return callThreatFunction<ThreatFeed>({ action: 'feed' }).then((feed) => {
    if (!feed.kev || !feed.advisories || !Array.isArray(feed.kev.recent) || !Array.isArray(feed.advisories.items)) {
      throw new Error('The threat intelligence service returned an unexpected response.');
    }
    return feed;
  });
}

export function lookupThreat(query: string): Promise<ThreatLookupResult> {
  return callThreatFunction<ThreatLookupResult>({ action: 'lookup', query }).then((result) => {
    if (!Array.isArray(result.items)) throw new Error('The threat intelligence service returned an unexpected response.');
    return result;
  });
}

export async function fetchRecentLookups(limit = 8): Promise<ThreatLookupRow[]> {
  if (!supabase) throw new Error(BACKEND_NOT_CONFIGURED_MESSAGE);
  const { data, error } = await supabase
    .from('threat_lookups')
    .select('id, query, kind, match_count, created_at')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw new Error('Could not load recent lookups.');
  return (data ?? []) as ThreatLookupRow[];
}
