import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const isBackendConfigured = Boolean(url && anonKey);
export const BACKEND_NOT_CONFIGURED_MESSAGE =
  'The local FastAPI scanner is not connected. Start the backend and configure VITE_SCAN_API_URL.';

export const supabase: SupabaseClient | null = url && anonKey ? createClient(url, anonKey) : null;
export const SCAN_FUNCTION_URL: string | null = url ? `${url}/functions/v1/scan-domain` : null;
export const THREAT_FUNCTION_URL: string | null = url ? `${url}/functions/v1/threat-intel` : null;
export const SUPABASE_ANON_KEY: string = anonKey ?? '';
