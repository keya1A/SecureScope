export interface KevItem {
  id: string;
  vendor: string;
  product: string;
  name: string;
  dateAdded: string;
  dueDate: string;
  requiredAction: string;
  ransomware: boolean;
}

export interface CveItem {
  id: string;
  description: string;
  cvss: number | null;
  severity: string;
  published: string;
  references: string[];
  kev: boolean;
}

export interface ThreatFeed {
  fetchedAt: string;
  kev: { total: number; recent: KevItem[]; error: string | null };
  advisories: { windowDays: number; items: CveItem[]; error: string | null };
}

export interface ThreatLookupResult {
  query: string;
  kind: 'cve' | 'keyword';
  items: CveItem[];
}

export interface ThreatLookupRow {
  id: string;
  query: string;
  kind: 'cve' | 'keyword';
  match_count: number;
  created_at: string;
}
