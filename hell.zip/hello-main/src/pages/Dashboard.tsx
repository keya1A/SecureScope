import { useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Loader2, Plus, ArrowUpRight, Clock, Activity } from 'lucide-react';
import { Card, EmptyState, RiskGauge, SeverityChart, RISK_COLORS } from '@/components/ui';
import { fetchRecentScans } from '@/services/scanService';
import { countBySeverity, formatDate, formatDuration } from '@/utils/report';
import type { ScanRow } from '@/types/scan';

export default function Dashboard() {
  const [scans, setScans] = useState<ScanRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchRecentScans()
      .then(setScans)
      .catch((err: Error) => setError(err.message));
  }, []);

  if (error) return <Message title="Dashboard unavailable" body={error} />;
  if (!scans) {
    return (
      <div className="flex h-64 items-center justify-center text-muted">
        <Loader2 className="mr-2 h-5 w-5 animate-spin text-primary" /> Loading scans
      </div>
    );
  }
  if (scans.length === 0) {
    return (
      <div className="mx-auto max-w-xl py-16 text-center">
        <Activity className="mx-auto h-10 w-10 text-primary" />
        <h1 className="mt-4 text-2xl font-bold">No scans yet</h1>
        <p className="mt-2 text-muted">Run your first assessment to see risk scores, findings, and charts here.</p>
        <Link to="/new-scan" className="btn-primary mt-6">Start a security scan</Link>
      </div>
    );
  }

  const latest = scans[0];
  const result = latest.result;
  const counts = countBySeverity(result);
  const total = result.findings.length;

  return (
    <div className="space-y-8">
      <PageHeader
        title="Security dashboard"
        subtitle={`Latest assessment: ${latest.domain}`}
        action={<Link to="/new-scan" className="btn-primary"><Plus className="h-4 w-4" />New scan</Link>}
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard label="Target domain" value={latest.domain} small />
        <KpiCard label="Scan date" value={formatDate(latest.created_at)} small />
        <KpiCard label="Scan status" value="Completed" accent="text-success" small />
        <KpiCard label="Scan duration" value={formatDuration(latest.duration_ms)} small />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <KpiCard label="Total findings" value={String(total)} />
        <KpiCard label="Critical" value={String(counts.Critical)} accent="text-critical" />
        <KpiCard label="High" value={String(counts.High)} accent="text-primary" />
        <KpiCard label="Medium" value={String(counts.Medium)} accent="text-warning" />
        <KpiCard label="Low" value={String(counts.Low)} accent="text-muted" />
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <Card title="Risk overview" subtitle="Weighted score from findings, CVSS, and exploitation data" className="xl:col-span-1">
          <div className="flex flex-col items-center gap-5">
            <RiskGauge score={result.risk.score} category={result.risk.category} />
            <div className="grid w-full grid-cols-2 gap-3 text-center text-sm">
              <div className="rounded-xl bg-secondary p-3">
                <p className="text-xs uppercase tracking-wider text-muted">Risk category</p>
                <p className="mt-1 font-semibold" style={{ color: RISK_COLORS[result.risk.category] }}>{result.risk.category}</p>
              </div>
              <div className="rounded-xl bg-secondary p-3">
                <p className="text-xs uppercase tracking-wider text-muted">ML predicted risk</p>
                <p className="mt-1 font-semibold text-muted">Not built</p>
              </div>
            </div>
            <p className="text-center text-xs leading-relaxed text-muted">{result.risk.summary}</p>
          </div>
        </Card>

        <Card title="Findings by severity" subtitle={`${total} security finding(s) in the latest scan`} className="xl:col-span-2">
          <SeverityChart counts={counts} />
          <div className="mt-4 flex items-center justify-between text-xs text-muted">
            <span>Total security findings</span>
            <Link to={`/findings/${latest.id}`} className="inline-flex items-center gap-1 text-primary hover:underline">
              Review all findings <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </Card>
      </div>

      <Card title="Scan history" subtitle="Every assessment stored in your workspace">
        {scans.length === 0 ? (
          <EmptyState message="No scans yet." />
        ) : (
          <ul className="divide-y divide-white/5">
            {scans.map((scan, index) => (
              <motion.li key={scan.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: index * 0.03 }}>
                <Link to={`/results/${scan.id}`} className="group flex flex-col gap-3 py-4 transition hover:bg-white/[0.02] sm:flex-row sm:items-center sm:justify-between sm:px-2">
                  <div className="min-w-0">
                    <p className="truncate font-mono text-sm font-semibold group-hover:text-primary">{scan.domain}</p>
                    <p className="mt-1 flex items-center gap-2 text-xs text-muted">
                      <Clock className="h-3 w-3" /> {formatDate(scan.created_at)} - {formatDuration(scan.duration_ms)}
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-sm tabular-nums text-muted">{scan.result.findings.length} findings</span>
                    <span className="rounded-full px-3 py-1 text-xs font-semibold tabular-nums" style={{ color: RISK_COLORS[scan.risk_category ?? 'Low'], backgroundColor: `${RISK_COLORS[scan.risk_category ?? 'Low']}1f` }}>
                      {scan.risk_score ?? 0} {scan.risk_category}
                    </span>
                    <ArrowUpRight className="h-4 w-4 text-muted transition group-hover:text-primary" />
                  </div>
                </Link>
              </motion.li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
        {subtitle && <p className="mt-2 text-muted">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

function KpiCard({ label, value, accent = 'text-white', small = false }: { label: string; value: string; accent?: string; small?: boolean }) {
  return (
    <motion.div whileHover={{ y: -3 }} className="glass-card p-5 transition hover:shadow-glow">
      <p className="text-xs uppercase tracking-wider text-muted">{label}</p>
      <p className={`mt-2 break-words font-semibold ${small ? 'text-sm' : 'text-3xl tabular-nums'} ${accent}`}>{value}</p>
    </motion.div>
  );
}

export function Message({ title, body }: { title: string; body: string }) {
  return (
    <div className="mx-auto mt-16 max-w-lg rounded-2xl border border-critical/30 bg-critical/10 p-6 text-center">
      <h1 className="text-lg font-semibold">{title}</h1>
      <p className="mt-2 text-sm text-muted">{body}</p>
    </div>
  );
}
