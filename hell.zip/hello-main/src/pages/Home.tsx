import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Globe, Lock, Radar, ScanLine, ShieldCheck, Gauge, FileText, Network } from 'lucide-react';
import Logo from '@/components/Logo';

const FEATURES = [
  { icon: ShieldCheck, title: 'HTTP security headers', text: 'Checks CSP, HSTS, X-Frame-Options, and more, with the impact of every gap.' },
  { icon: Lock, title: 'Cookie and TLS analysis', text: 'Verifies Secure, HttpOnly, and SameSite flags plus certificate validity and expiry.' },
  { icon: Network, title: 'DNS and WHOIS intelligence', text: 'Reads A, MX, TXT, CAA and more, and tests SPF, DMARC, DKIM, and DNSSEC.' },
  { icon: Radar, title: 'Technology and CVE correlation', text: 'Detects server and framework versions and matches them against NVD and CISA KEV.' },
  { icon: Gauge, title: 'Transparent risk score', text: 'A 0 to 100 weighted score with a breakdown that explains exactly why it was given.' },
  { icon: FileText, title: 'Professional reports', text: 'Export remediation-ready reports as text or PDF for stakeholders.' },
];

export default function Home() {
  const navigate = useNavigate();
  const [domain, setDomain] = useState('');

  function handleStart(event: FormEvent) {
    event.preventDefault();
    const target = domain.trim();
    if (!target) return;
    navigate(`/new-scan?domain=${encodeURIComponent(target)}`);
  }

  return (
    <div className="min-h-screen overflow-hidden bg-background">
      <header className="sticky top-0 z-30 border-b border-white/5 bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link to="/"><Logo /></Link>
          <nav className="hidden items-center gap-8 text-sm text-muted md:flex">
            <a href="#home" className="transition hover:text-white">Home</a>
            <a href="#features" className="transition hover:text-white">Features</a>
            <a href="#about" className="transition hover:text-white">About</a>
          </nav>
          <Link to="/dashboard" className="rounded-xl border border-white/10 px-4 py-2 text-sm font-semibold transition hover:border-primary/50 hover:text-primary">Dashboard</Link>
        </div>
      </header>

      <section id="home" className="relative mx-auto max-w-6xl px-6 pb-24 pt-20 text-center">
        <div className="pointer-events-none absolute inset-x-0 -top-20 mx-auto h-96 max-w-3xl rounded-full bg-primary/15 blur-[120px]" />
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="relative">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-semibold text-primary">
            <ScanLine className="h-3.5 w-3.5" /> Non-invasive web security assessment
          </span>
          <h1 className="glow-text mx-auto mt-6 max-w-4xl text-4xl font-bold leading-[1.1] tracking-tight sm:text-6xl">
            Discover the Security Behind <span className="text-primary">Every Website.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-muted">
            Intelligent Web Security Assessment and Risk Analysis Platform.
          </p>

          <form onSubmit={handleStart} className="mx-auto mt-10 flex max-w-2xl flex-col gap-3 rounded-2xl border border-white/10 bg-card p-2 shadow-glow sm:flex-row">
            <div className="relative flex-1">
              <Globe className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
              <input
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                placeholder="Enter authorized domain (example.com)"
                aria-label="Enter authorized domain"
                className="w-full rounded-xl bg-transparent py-3.5 pl-11 pr-4 font-mono text-sm text-white placeholder:text-muted/70 outline-none"
              />
            </div>
            <button type="submit" disabled={!domain.trim()} className="btn-primary whitespace-nowrap">
              START SECURITY SCAN <ArrowRight className="h-4 w-4" />
            </button>
          </form>

          <p className="mx-auto mt-5 max-w-2xl text-xs leading-relaxed text-muted">
            <Lock className="mr-1 inline h-3 w-3 text-primary" />
            Authorization notice: only scan domains you own or have written permission to assess. Local and private addresses are blocked.
          </p>
        </motion.div>
      </section>

      <section id="features" className="mx-auto max-w-6xl px-6 py-24">
        <div className="mb-12 text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Features</p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight">Everything a security review needs, in one scan</h2>
        </div>
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {FEATURES.map(({ icon: Icon, title, text }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              whileHover={{ y: -4 }}
              className="glass-card p-6 transition hover:shadow-glow"
            >
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="font-semibold">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{text}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section id="about" className="mx-auto max-w-6xl px-6 pb-24">
        <div className="glass-card grid gap-8 p-10 md:grid-cols-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">About</p>
            <h2 className="mt-3 text-2xl font-bold">Built for clear, explainable security assessment</h2>
          </div>
          <p className="text-sm leading-relaxed text-muted">
            SecureScope runs passive checks against a domain you are authorized to test, then turns the observations into prioritized findings with evidence and remediation steps. Every score can be traced back to the checks that produced it.{' '}
            <Link to="/about" className="text-primary hover:underline">Read the project overview</Link>.
          </p>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8 text-center text-xs text-muted">
        SecureScope - Only scan domains you are authorized to assess.
      </footer>
    </div>
  );
}
