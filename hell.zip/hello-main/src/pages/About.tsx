import { Link } from 'react-router-dom';
import { Card } from '@/components/ui';
import { PageHeader } from '@/pages/Dashboard';

const PIPELINE = [
  'Domain validation: format, scope, and private or local address checks',
  'DNS analysis: A, AAAA, CNAME, MX, NS, TXT, SOA, CAA, SPF, DMARC, DKIM, DNSSEC',
  'HTTP header and cookie analysis of one HTTPS request, plus an HTTP to HTTPS redirect test',
  'SSL/TLS certificate lookup in public Certificate Transparency logs',
  'WHOIS data through the RDAP registration service',
  'Technology detection from headers, cookies, and page markup',
  'CVE correlation through NVD configuration ranges, cross-checked against the CISA KEV catalog',
  'Weighted risk scoring and report generation',
];

const LIMITS = [
  'Checks are passive. No exploits, fuzzing, or intrusive tests are run.',
  'The TLS version negotiated by the server is not measured by the scanner runtime.',
  'The machine-learning risk classifier is not part of this build. The displayed score is the separate weighted formula.',
  'Certificate details come from public logs and may differ from the certificate currently served.',
];

export default function About() {
  return (
    <div className="mx-auto max-w-4xl space-y-8">
      <PageHeader title="About SecureScope" subtitle="A web security assessment platform for authorized domains" />

      <Card title="Purpose">
        <p className="text-sm leading-relaxed text-muted">
          SecureScope helps students, developers, and administrators find common website security weaknesses before attackers do.
          It turns raw configuration data into prioritized findings, each with evidence, impact, and a concrete fix.
        </p>
      </Card>

      <Card title="How a scan works">
        <ol className="space-y-3">
          {PIPELINE.map((step, i) => (
            <li key={step} className="flex gap-4 text-sm">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/15 text-xs font-semibold text-primary">{i + 1}</span>
              <span className="text-muted">{step}</span>
            </li>
          ))}
        </ol>
      </Card>

      <Card title="Scope and limitations">
        <ul className="list-disc space-y-2 pl-5 text-sm text-muted">
          {LIMITS.map((item) => <li key={item}>{item}</li>)}
        </ul>
        <p className="mt-6 text-sm">
          Ready to try it? <Link to="/new-scan" className="text-primary hover:underline">Start a new scan</Link>.
        </p>
      </Card>
    </div>
  );
}
