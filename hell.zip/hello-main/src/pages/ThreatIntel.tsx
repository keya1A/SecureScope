import { useCallback, useEffect, useState } from 'react';
import { Loader2, RefreshCw } from 'lucide-react';
import { Card } from '@/components/ui';
import { PageHeader, Message } from '@/pages/Dashboard';
import AdvisoryCard from '@/components/threat/AdvisoryCard';
import CveLookupCard from '@/components/threat/CveLookupCard';
import KevFeedCard from '@/components/threat/KevFeedCard';
import { fetchThreatFeed } from '@/services/threatService';
import { formatDate } from '@/utils/report';
import type { ThreatFeed } from '@/types/threat';

export default function ThreatIntel() {
  const [feed, setFeed] = useState<ThreatFeed | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const loadFeed = useCallback(() => {
    setRefreshing(true);
    fetchThreatFeed()
      .then((data) => {
        setFeed(data);
        setError(null);
      })
      .catch((err: Error) => setError(err.message))
      .finally(() => setRefreshing(false));
  }, []);

  useEffect(loadFeed, [loadFeed]);

  if (error && !feed) return <Message title="Threat intelligence unavailable" body={error} />;
  if (!feed) {
    return (
      <div className="flex h-64 items-center justify-center text-muted">
        <Loader2 className="mr-2 h-5 w-5 animate-spin text-primary" /> Loading live threat feeds
      </div>
    );
  }

  const exploitedAdvisories = feed.advisories.items.filter((cve) => cve.kev).length;

  return (
    <div className="space-y-8">
      <PageHeader
        title="Threat intelligence"
        subtitle={`Live feeds from CISA and NVD. Updated ${formatDate(feed.fetchedAt)}`}
        action={
          <button onClick={loadFeed} disabled={refreshing} className="inline-flex items-center gap-2 rounded-xl border border-white/10 px-4 py-2.5 text-sm font-semibold transition hover:bg-white/5 disabled:opacity-60">
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} /> Refresh feeds
          </button>
        }
      />

      {error && <p className="rounded-xl border border-critical/30 bg-critical/10 p-4 text-sm text-muted">The latest refresh failed: {error}</p>}

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="Catalog entries" value={feed.kev.total.toLocaleString()} />
        <Stat label="Critical advisories" value={String(feed.advisories.items.length)} accent="text-critical" />
        <Stat label="Advisories exploited in the wild" value={String(exploitedAdvisories)} accent="text-primary" />
      </div>

      <CveLookupCard />

      <div className="grid gap-6 xl:grid-cols-2">
        <KevFeedCard total={feed.kev.total} items={feed.kev.recent} error={feed.kev.error} />
        <AdvisoryCard windowDays={feed.advisories.windowDays} items={feed.advisories.items} error={feed.advisories.error} />
      </div>

      <Card>
        <p className="text-xs leading-relaxed text-muted">
          Known exploited vulnerabilities come from the CISA catalog. Advisories come from the NVD database and may lag behind vendor announcements.
          Lookups only read public vulnerability data and never contact the systems you search for.
        </p>
      </Card>
    </div>
  );
}

function Stat({ label, value, accent = 'text-white' }: { label: string; value: string; accent?: string }) {
  return (
    <div className="glass-card p-5">
      <p className="text-xs uppercase tracking-wider text-muted">{label}</p>
      <p className={`mt-2 text-3xl font-semibold tabular-nums ${accent}`}>{value}</p>
    </div>
  );
}
