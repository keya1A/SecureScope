import { useEffect, useMemo, useState } from 'react';
import { Download, Printer, Loader2, FileText } from 'lucide-react';
import { Card, EmptyState } from '@/components/ui';
import { PageHeader, Message } from '@/pages/Dashboard';
import { fetchRecentScans } from '@/services/scanService';
import { buildTxtReport, downloadText, formatDate } from '@/utils/report';
import type { ScanRow } from '@/types/scan';

export default function Reports() {
  const [scans, setScans] = useState<ScanRow[] | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchRecentScans()
      .then((rows) => {
        setScans(rows);
        setSelectedId(rows[0]?.id ?? null);
      })
      .catch((err: Error) => setError(err.message));
  }, []);

  const selected = useMemo(() => scans?.find((s) => s.id === selectedId) ?? null, [scans, selectedId]);
  const report = useMemo(() => (selected ? buildTxtReport(selected.result, selected.id) : ''), [selected]);

  if (error) return <Message title="Reports unavailable" body={error} />;
  if (!scans) {
    return (
      <div className="flex h-64 items-center justify-center text-muted">
        <Loader2 className="mr-2 h-5 w-5 animate-spin text-primary" /> Loading reports
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader title="Security reports" subtitle="Generate a text or PDF report from any completed scan" />

      {scans.length === 0 ? (
        <Card><EmptyState message="Run a scan first. Completed scans appear here as reports." /></Card>
      ) : (
        <div className="grid gap-6 xl:grid-cols-[320px_1fr]">
          <Card title="Completed scans" className="no-print h-fit">
            <ul className="space-y-2">
              {scans.map((scan) => (
                <li key={scan.id}>
                  <button
                    onClick={() => setSelectedId(scan.id)}
                    className={`w-full rounded-xl border p-3 text-left transition ${scan.id === selectedId ? 'border-primary/40 bg-primary/10' : 'border-white/5 bg-secondary hover:border-white/15'}`}
                  >
                    <p className="truncate font-mono text-sm">{scan.domain}</p>
                    <p className="mt-1 text-xs text-muted">{formatDate(scan.created_at)} - Risk {scan.risk_score ?? 0}</p>
                  </button>
                </li>
              ))}
            </ul>
          </Card>

          {selected && (
            <Card
              title={`Report: ${selected.domain}`}
              subtitle="Preview of the report content"
              action={
                <div className="no-print flex gap-2">
                  <button onClick={() => downloadText(`securescope-${selected.domain}.txt`, report)} className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold transition hover:bg-[#f0505c]">
                    <Download className="h-4 w-4" /> TXT
                  </button>
                  <button onClick={() => window.print()} className="inline-flex items-center gap-2 rounded-xl border border-white/10 px-4 py-2.5 text-sm font-semibold transition hover:bg-white/5">
                    <Printer className="h-4 w-4" /> PDF
                  </button>
                </div>
              }
            >
              <div className="mb-4 flex items-center gap-2 text-xs text-muted no-print">
                <FileText className="h-3.5 w-3.5" /> The PDF option opens your browser print dialog. Choose "Save as PDF" as the destination.
              </div>
              <pre className="max-h-[70vh] overflow-auto whitespace-pre-wrap rounded-xl bg-[#050505] p-5 font-mono text-xs leading-relaxed text-white/85">{report}</pre>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
