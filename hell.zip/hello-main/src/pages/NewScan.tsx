import { useEffect, useState, type FormEvent } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Loader2, CheckCircle2, AlertTriangle, XCircle, Play } from 'lucide-react';
import { Card } from '@/components/ui';
import { runSecurityScan } from '@/services/scanService';
import type { LogEntry, ModuleResult, ScanResult } from '@/types/scan';

type Phase = 'idle' | 'running' | 'replaying' | 'done' | 'error';

const LOG_STEP_MS = 220;

export default function NewScan() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [domain, setDomain] = useState(searchParams.get('domain') ?? '');
  const [authorized, setAuthorized] = useState(false);
  const [phase, setPhase] = useState<Phase>('idle');
  const [error, setError] = useState<string | null>(null);
  const [scanId, setScanId] = useState<string | null>(null);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [visibleLogs, setVisibleLogs] = useState(0);

  useEffect(() => {
    if (phase !== 'replaying' || !result) return;
    const timer = window.setInterval(() => {
      setVisibleLogs((count) => Math.min(result.log.length, count + 1));
    }, LOG_STEP_MS);
    return () => window.clearInterval(timer);
  }, [phase, result]);

  useEffect(() => {
    if (phase === 'replaying' && result && visibleLogs >= result.log.length) setPhase('done');
  }, [phase, result, visibleLogs]);

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    if (!authorized) {
      setError('Confirm that you are authorized to assess this domain.');
      return;
    }
    setPhase('running');
    setVisibleLogs(0);
    try {
      const response = await runSecurityScan(domain.trim());
      setScanId(response.id);
      setResult(response.result);
      setPhase('replaying');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'The scan failed.');
      setPhase('error');
    }
  }

  const busy = phase === 'running' || phase === 'replaying';
  const shownLogs = result?.log.slice(0, visibleLogs) ?? [];
  const shownModules = result?.modules.filter((m) => shownLogs.some((l) => l.module === m.id)) ?? [];

  return (
    <div className="mx-auto max-w-5xl space-y-8">
      <header>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">New security scan</p>
        <h1 className="mt-2 text-3xl font-bold tracking-tight">Assess an authorized domain</h1>
        <p className="mt-2 max-w-2xl text-muted">The scanner performs passive, non-invasive checks only. No exploits or intrusive tests are run.</p>
      </header>

      <Card>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="domain" className="mb-2 block text-sm font-medium text-muted">Target domain</label>
            <input
              id="domain"
              className="input-base font-mono"
              placeholder="example.com"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              disabled={busy}
              required
            />
          </div>
          <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-primary/20 bg-primary/5 p-4 text-sm text-muted">
            <input
              type="checkbox"
              checked={authorized}
              onChange={(e) => setAuthorized(e.target.checked)}
              disabled={busy}
              className="mt-0.5 h-4 w-4 accent-[#E63946]"
            />
            <span>I confirm that I own this domain or have written authorization to assess it. Private, local, and internal addresses are blocked.</span>
          </label>
          {error && (
            <div className="flex items-start gap-3 rounded-xl border border-critical/30 bg-critical/10 p-4 text-sm text-critical">
              <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
          <button type="submit" className="btn-primary" disabled={busy || !domain.trim()}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
            {busy ? 'Scan in progress' : 'Start security scan'}
          </button>
        </form>
      </Card>

      {phase !== 'idle' && phase !== 'error' && (
        <ScanProgress
          phase={phase}
          allModules={result?.modules ?? []}
          modules={shownModules}
          logs={shownLogs}
          onOpen={() => scanId && navigate(`/results/${scanId}`)}
          domain={domain.trim()}
        />
      )}
    </div>
  );
}

function ScanProgress({ phase, allModules, modules, logs, onOpen, domain }: {
  phase: Phase;
  allModules: ModuleResult[];
  modules: ModuleResult[];
  logs: LogEntry[];
  onOpen: () => void;
  domain: string;
}) {
  const done = phase === 'done';
  const progress = done ? 100 : phase === 'running' ? 8 : Math.round((modules.length / Math.max(allModules.length, 1)) * 90 + 8);

  return (
    <Card title="Scan progress" subtitle={`Target: ${domain}`} action={
      <span className={`rounded-full px-3 py-1 text-xs font-semibold ${done ? 'bg-success/15 text-success' : 'bg-primary/15 text-primary'}`}>
        {done ? 'Completed' : phase === 'running' ? 'Scanning' : 'Reporting'}
      </span>
    }>
      <div className="mb-6">
        <div className="mb-2 flex justify-between text-xs text-muted">
          <span>{phase === 'running' ? 'Waiting for the scanner to finish all checks' : 'Replaying the scanner activity log'}</span>
          <span className="tabular-nums">{progress}%</span>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-secondary">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-dark to-primary shadow-glow"
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.4 }}
          />
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <ul className="space-y-2 lg:col-span-2">
          {allModules.length === 0 && (
            <li className="flex items-center gap-3 rounded-xl bg-secondary p-3 text-sm text-muted">
              <Loader2 className="h-4 w-4 animate-spin text-primary" /> Running all modules on the server
            </li>
          )}
          {modules.map((m) => (
            <motion.li key={m.id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} className="flex items-start gap-3 rounded-xl bg-secondary p-3">
              <ModuleIcon status={m.status} />
              <div className="min-w-0">
                <p className="text-sm font-medium">{m.label}</p>
                <p className="truncate text-xs text-muted">{m.message}</p>
              </div>
            </motion.li>
          ))}
        </ul>

        <div className="rounded-xl border border-white/5 bg-[#050505] p-4 font-mono text-xs leading-relaxed lg:col-span-3">
          <div className="mb-3 flex items-center gap-2 text-muted">
            <span className="h-2.5 w-2.5 rounded-full bg-critical" />
            <span className="h-2.5 w-2.5 rounded-full bg-warning" />
            <span className="h-2.5 w-2.5 rounded-full bg-success" />
            <span className="ml-2">scan-activity.log</span>
          </div>
          <div className="max-h-72 space-y-1 overflow-y-auto">
            {logs.length === 0 && <p className="text-muted">$ waiting for scanner output...</p>}
            {logs.map((entry, i) => (
              <p key={i} className={entry.level === 'error' ? 'text-critical' : entry.level === 'warn' ? 'text-warning' : 'text-success/90'}>
                <span className="text-muted">[{new Date(entry.time).toLocaleTimeString()}]</span> {entry.module.padEnd(10)} {entry.message}
              </p>
            ))}
            {!done && phase === 'replaying' && <span className="inline-block h-3 w-1.5 animate-pulse bg-primary" />}
          </div>
        </div>
      </div>

      {done && (
        <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="mt-6 flex flex-col items-start justify-between gap-4 rounded-xl border border-success/25 bg-success/10 p-5 sm:flex-row sm:items-center">
          <div className="flex items-center gap-3 text-sm">
            <CheckCircle2 className="h-5 w-5 text-success" />
            <span>Scan complete. The results are saved to your dashboard and reports.</span>
          </div>
          <button onClick={onOpen} className="btn-primary">View results</button>
        </motion.div>
      )}
    </Card>
  );
}

function ModuleIcon({ status }: { status: ModuleResult['status'] }) {
  if (status === 'ok') return <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success" />;
  if (status === 'warning') return <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />;
  return <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-critical" />;
}
