import { useEffect, useState } from 'react';
import { Link, Navigate, useParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { ChevronDown, Loader2, ShieldCheck } from 'lucide-react';
import { Card, EmptyState, SeverityBadge, SEVERITY_COLORS } from '@/components/ui';
import { PageHeader, Message } from '@/pages/Dashboard';
import { fetchRecentScans, fetchScan } from '@/services/scanService';
import { SEVERITY_ORDER } from '@/utils/report';
import type { ScanRow, Severity } from '@/types/scan';

type Filter = Severity | 'All';
const FILTERS: Filter[] = ['All', ...SEVERITY_ORDER];

export default function Findings() {
  const { id } = useParams();
  const [scan, setScan] = useState<ScanRow | null | undefined>(undefined);
  const [latestId, setLatestId] = useState<string | null | undefined>(undefined);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<Filter>('All');
  const [openId, setOpenId] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      fetchScan(id).then(setScan).catch((err: Error) => setError(err.message));
    } else {
      fetchRecentScans(1)
        .then((rows) => setLatestId(rows[0]?.id ?? null))
        .catch((err: Error) => setError(err.message));
    }
  }, [id]);

  if (!id) {
    if (error) return <Message title="Findings unavailable" body={error} />;
    if (latestId === undefined) return <Loading />;
    if (latestId === null) return <NoScans />;
    return <Navigate to={`/findings/${latestId}`} replace />;
  }

  if (error) return <Message title="Findings unavailable" body={error} />;
  if (scan === undefined) return <Loading />;
  if (scan === null) return <Message title="Scan not found" body="This scan does not exist or was removed." />;

  const findings = [...scan.result.findings].sort(
    (a, b) => SEVERITY_ORDER.indexOf(a.severity) - SEVERITY_ORDER.indexOf(b.severity),
  );
  const visible = filter === 'All' ? findings : findings.filter((f) => f.severity === filter);

  return (
    <div className="space-y-8">
      <PageHeader
        title="Security findings"
        subtitle={`${findings.length} issue(s) detected on ${scan.domain}`}
        action={<Link to={`/results/${scan.id}`} className="inline-flex items-center gap-2 rounded-xl border border-white/10 px-5 py-3 text-sm font-semibold transition hover:bg-white/5">View scan results</Link>}
      />

      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => {
          const count = f === 'All' ? findings.length : findings.filter((x) => x.severity === f).length;
          const active = filter === f;
          const color = f === 'All' ? '#FFFFFF' : SEVERITY_COLORS[f];
          return (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className="rounded-full border px-4 py-1.5 text-xs font-semibold transition"
              style={{
                borderColor: active ? color : 'rgba(255,255,255,0.08)',
                color: active ? color : '#A1A1AA',
                backgroundColor: active ? `${color}1a` : 'transparent',
              }}
            >
              {f} <span className="ml-1 tabular-nums opacity-80">{count}</span>
            </button>
          );
        })}
      </div>

      {visible.length === 0 ? (
        <Card>
          <EmptyState message={findings.length === 0 ? 'No security issues were detected by the non-invasive checks.' : 'No findings match this severity.'} />
        </Card>
      ) : (
        <ul className="space-y-3">
          {visible.map((finding) => {
            const open = openId === finding.id;
            return (
              <motion.li key={finding.id} layout className="glass-card overflow-hidden">
                <button
                  onClick={() => setOpenId(open ? null : finding.id)}
                  className="flex w-full items-center gap-4 p-5 text-left transition hover:bg-white/[0.02]"
                  aria-expanded={open}
                >
                  <span className="h-10 w-1 shrink-0 rounded-full" style={{ backgroundColor: SEVERITY_COLORS[finding.severity] }} />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-3">
                      <SeverityBadge severity={finding.severity} />
                      <span className="text-xs text-muted">{finding.confidence} - {finding.module}</span>
                    </div>
                    <p className="mt-2 font-semibold">{finding.title}</p>
                    <p className="truncate font-mono text-xs text-muted">{finding.asset}</p>
                  </div>
                  <ChevronDown className={`h-4 w-4 shrink-0 text-muted transition ${open ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence initial={false}>
                  {open && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }}>
                      <div className="grid gap-5 border-t border-white/5 p-5 text-sm md:grid-cols-2">
                        <Detail label="Description" value={finding.description} />
                        <Detail label="Evidence" value={finding.evidence} mono />
                        <Detail label="Security impact" value={finding.impact} />
                        <Detail label="Recommended remediation" value={finding.remediation} highlight />
                        {finding.cveId && <Detail label="CVE reference" value={finding.cveId} mono />}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function Detail({ label, value, mono = false, highlight = false }: { label: string; value: string; mono?: boolean; highlight?: boolean }) {
  return (
    <div className={`rounded-xl p-4 ${highlight ? 'bg-success/10' : 'bg-secondary'}`}>
      <p className="text-xs uppercase tracking-wider text-muted">{label}</p>
      <p className={`mt-2 leading-relaxed ${mono ? 'break-all font-mono text-xs' : ''}`}>{value}</p>
    </div>
  );
}

function Loading() {
  return (
    <div className="flex h-64 items-center justify-center text-muted">
      <Loader2 className="mr-2 h-5 w-5 animate-spin text-primary" /> Loading findings
    </div>
  );
}

function NoScans() {
  return (
    <div className="mx-auto max-w-md py-16 text-center">
      <ShieldCheck className="mx-auto h-10 w-10 text-primary" />
      <h1 className="mt-4 text-2xl font-bold">No findings yet</h1>
      <p className="mt-2 text-muted">Run a scan to see security issues here.</p>
      <Link to="/new-scan" className="btn-primary mt-6">Start a security scan</Link>
    </div>
  );
}
