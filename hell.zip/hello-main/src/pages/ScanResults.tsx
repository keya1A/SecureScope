import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Loader2, ShieldAlert, FileText } from 'lucide-react';
import { Card, RiskGauge, SeverityChart, StatusBadge, RISK_COLORS } from '@/components/ui';
import { DnsPanel, HeaderPanel, IntelPanel, TlsPanel } from '@/components/results/ScanPanels';
import { PageHeader, Message } from '@/pages/Dashboard';
import { fetchScan } from '@/services/scanService';
import { countBySeverity, formatDate, formatDuration } from '@/utils/report';
import type { ScanRow } from '@/types/scan';

const TABS = [
  { id: 'overview', label: 'Overview' },
  { id: 'http', label: 'Headers & Cookies' },
  { id: 'tls', label: 'SSL/TLS' },
  { id: 'dns', label: 'DNS & WHOIS' },
  { id: 'intel', label: 'Technology & CVEs' },
] as const;

type TabId = (typeof TABS)[number]['id'];

export default function ScanResults() {
  const { id } = useParams();
  const [scan, setScan] = useState<ScanRow | null | undefined>(undefined);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<TabId>('overview');

  useEffect(() => {
    if (!id) return;
    fetchScan(id)
      .then((row) => setScan(row))
      .catch((err: Error) => setError(err.message));
  }, [id]);

  if (error) return <Message title="Results unavailable" body={error} />;
  if (scan === undefined) {
    return (
      <div className="flex h-64 items-center justify-center text-muted">
        <Loader2 className="mr-2 h-5 w-5 animate-spin text-primary" /> Loading results
      </div>
    );
  }
  if (scan === null) return <Message title="Scan not found" body="This scan does not exist or was removed." />;

  const { result } = scan;
  const counts = countBySeverity(result);

  return (
    <div className="space-y-8">
      <PageHeader
        title={result.domain}
        subtitle={`Scanned ${formatDate(scan.created_at)} in ${formatDuration(scan.duration_ms)}`}
        action={
          <div className="flex gap-3">
            <Link to={`/findings/${scan.id}`} className="btn-primary"><ShieldAlert className="h-4 w-4" />Findings</Link>
            <Link to="/reports" className="inline-flex items-center gap-2 rounded-xl border border-white/10 px-5 py-3 text-sm font-semibold text-white transition hover:bg-white/5"><FileText className="h-4 w-4" />Report</Link>
          </div>
        }
      />

      <div className="flex gap-2 overflow-x-auto border-b border-white/5 pb-px">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative whitespace-nowrap px-4 py-3 text-sm font-medium transition ${tab === t.id ? 'text-white' : 'text-muted hover:text-white'}`}
          >
            {t.label}
            {tab === t.id && <motion.span layoutId="scan-tab" className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-primary shadow-glow" />}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="space-y-6">
          <div className="grid gap-6 xl:grid-cols-3">
            <Card title="Overall risk score" subtitle="Calculated from findings, CVSS, and exploitation data" className="flex flex-col items-center">
              <RiskGauge score={result.risk.score} category={result.risk.category} />
              <p className="mt-4 text-sm font-semibold" style={{ color: RISK_COLORS[result.risk.category] }}>{result.risk.category} risk</p>
              <p className="mt-2 text-center text-xs text-muted">{result.risk.summary}</p>
            </Card>
            <Card title="Severity distribution" subtitle={`${result.findings.length} finding(s)`} className="xl:col-span-2">
              <SeverityChart counts={counts} />
            </Card>
          </div>
          <div className="grid gap-6 xl:grid-cols-2">
            <Card title="Why this score" subtitle="Each component is capped so the total stays within 0 to 100">
              <ul className="space-y-4">
                {result.risk.factors.map((f) => (
                  <li key={f.label}>
                    <div className="flex justify-between text-sm">
                      <span>{f.label}</span>
                      <span className="tabular-nums text-muted">{f.points} / {f.maxPoints}</span>
                    </div>
                    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary">
                      <motion.div className="h-full rounded-full bg-primary" initial={{ width: 0 }} animate={{ width: `${(f.points / f.maxPoints) * 100}%` }} transition={{ duration: 0.8 }} />
                    </div>
                    <p className="mt-1.5 text-xs text-muted">{f.detail}</p>
                  </li>
                ))}
              </ul>
            </Card>
            <Card title="Module status" subtitle="Result of each check in this scan">
              <ul className="divide-y divide-white/5">
                {result.modules.map((m) => (
                  <li key={m.id} className="flex items-start justify-between gap-4 py-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium">{m.label}</p>
                      <p className="text-xs text-muted">{m.message}</p>
                    </div>
                    <StatusBadge status={m.status} />
                  </li>
                ))}
              </ul>
            </Card>
          </div>
        </div>
      )}
      {tab === 'http' && <HeaderPanel http={result.http} />}
      {tab === 'tls' && <TlsPanel tls={result.tls} />}
      {tab === 'dns' && <DnsPanel dns={result.dns} whois={result.whois} />}
      {tab === 'intel' && <IntelPanel technologies={result.technologies} cves={result.cves} cveNotes={result.cveNotes} />}
    </div>
  );
}
