import type { ScanResult, Severity } from '@/types/scan';

export const SEVERITY_ORDER: Severity[] = ['Critical', 'High', 'Medium', 'Low', 'Informational'];

export function countBySeverity(result: ScanResult): Record<Severity, number> {
  const counts: Record<Severity, number> = { Critical: 0, High: 0, Medium: 0, Low: 0, Informational: 0 };
  for (const finding of result.findings) counts[finding.severity] += 1;
  return counts;
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}

export function formatDuration(ms: number): string {
  return ms < 1000 ? `${ms} ms` : `${(ms / 1000).toFixed(1)} s`;
}

export function buildTxtReport(result: ScanResult, scanId: string): string {
  const counts = countBySeverity(result);
  const line = '='.repeat(72);
  const sub = '-'.repeat(72);
  const lines: string[] = [];
  const push = (...items: string[]) => lines.push(...items);

  push(line, 'SECURESCOPE SECURITY ASSESSMENT REPORT', line, '');
  push(`Target domain:     ${result.domain}`, `Scan date:        ${formatDate(result.scannedAt)}`, `Scan ID:          ${scanId}`, `Scan duration:    ${formatDuration(result.durationMs)}`, '');

  push('EXECUTIVE SUMMARY', sub);
  push(`Overall risk score: ${result.risk.score} / 100 (${result.risk.category})`);
  push(result.risk.summary);
  push(`Findings: ${result.findings.length} total - Critical ${counts.Critical}, High ${counts.High}, Medium ${counts.Medium}, Low ${counts.Low}, Informational ${counts.Informational}`, '');

  push('RISK SCORE BREAKDOWN', sub);
  for (const f of result.risk.factors) push(`- ${f.label}: ${f.points} / ${f.maxPoints}. ${f.detail}`);
  push('');

  push('HTTP HEADER ANALYSIS', sub);
  if (result.http.headers.length === 0) push('No HTTP response was received, so headers were not analyzed.');
  for (const h of result.http.headers) push(`- ${h.name}: ${h.status.toUpperCase()}${h.value ? ` (${h.value})` : ''}`);
  push('', 'Cookies:');
  if (result.http.cookies.length === 0) push('- No cookies were set by the site.');
  for (const c of result.http.cookies) push(`- ${c.name}: Secure=${c.secure} HttpOnly=${c.httpOnly} SameSite=${c.sameSite ?? 'not set'}`);
  push('');

  push('SSL/TLS ANALYSIS', sub);
  const t = result.tls;
  push(`Status: ${t.status}`, `Subject: ${t.subject ?? 'n/a'}`, `Issuer: ${t.issuer ?? 'n/a'}`, `Valid from: ${t.validFrom ?? 'n/a'}`, `Valid until: ${t.validUntil ?? 'n/a'}`, `Days remaining: ${t.daysRemaining ?? 'n/a'}`, `Chain valid: ${t.chainValid === null ? 'not determined' : t.chainValid}`, `TLS version: ${t.tlsVersion ?? 'not measured'}`, t.note, '');

  push('DNS AND WHOIS', sub);
  for (const [type, values] of Object.entries(result.dns.records)) push(`${type}: ${values.length ? values.join(' | ') : 'none'}`);
  push(`SPF: ${result.dns.security.spf.present ? 'present' : 'missing'}`, `DMARC: ${result.dns.security.dmarc.present ? `present (p=${result.dns.security.dmarc.policy ?? 'unknown'})` : 'missing'}`, `DKIM: ${result.dns.security.dkim.discovered ? result.dns.security.dkim.selectors.join(', ') : 'not discovered'}`, `DNSSEC: ${result.dns.security.dnssec}`);
  const w = result.whois;
  push(`Registrar: ${w.registrar ?? 'not disclosed'}`, `Registered: ${w.registeredOn ?? 'n/a'}`, `Expires: ${w.expiresOn ?? 'n/a'}`, `Domain age (days): ${w.ageDays ?? 'n/a'}`, `Name servers: ${w.nameServers.join(', ') || 'n/a'}`, '');

  push('TECHNOLOGY DETECTION', sub);
  if (result.technologies.length === 0) push('No technologies identified.');
  for (const tech of result.technologies) push(`- ${tech.name} (${tech.category})${tech.version ? ` ${tech.version}` : ''}: ${tech.evidence}`);
  push('');

  push('SECURITY FINDINGS', sub);
  for (const f of result.findings) {
    push(`[${f.severity.toUpperCase()}] ${f.title}`, `  Asset: ${f.asset}`, `  Description: ${f.description}`, `  Evidence: ${f.evidence}`, `  Security impact: ${f.impact}`, `  Remediation: ${f.remediation}`, `  Confidence: ${f.confidence}${f.cveId ? `  CVE: ${f.cveId}` : ''}`, '');
  }

  push('CVE INTELLIGENCE', sub);
  for (const note of result.cveNotes) push(`- ${note}`);
  if (result.cves.length === 0) push('No applicable CVE records were correlated.');
  for (const c of result.cves) push(`- ${c.id} | ${c.technology} ${c.version} | CVSS ${c.cvss ?? 'n/a'} (${c.severity}) | KEV: ${c.kev ? 'yes' : 'no'}`, `  ${c.description}`, `  ${c.references.join('\n  ')}`);
  push('');

  push('ML RISK ASSESSMENT', sub);
  push('Not available. The machine-learning classifier described in the project specification has not been built in this version.', '');

  push('REMEDIATION RECOMMENDATIONS', sub);
  const ordered = [...result.findings].sort((a, b) => SEVERITY_ORDER.indexOf(a.severity) - SEVERITY_ORDER.indexOf(b.severity));
  ordered.forEach((f, i) => push(`${i + 1}. [${f.severity}] ${f.remediation}`));
  push('', 'Scans are non-invasive. This report reflects publicly observable configuration only.', line);

  return lines.join('\n');
}

export function downloadText(filename: string, content: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const href = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = href;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(href);
}
