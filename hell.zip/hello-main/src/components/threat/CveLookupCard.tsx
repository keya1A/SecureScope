import { useEffect, useState, type FormEvent } from 'react';
import { Loader2, Search } from 'lucide-react';
import { Card, EmptyState } from '@/components/ui';
import CveRow from '@/components/threat/CveRow';
import { fetchRecentLookups, lookupThreat } from '@/services/threatService';
import { formatDate } from '@/utils/report';
import type { ThreatLookupResult, ThreatLookupRow } from '@/types/threat';

export default function CveLookupCard() {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<ThreatLookupResult | null>(null);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [recent, setRecent] = useState<ThreatLookupRow[]>([]);
  const [recentError, setRecentError] = useState<string | null>(null);

  const loadRecent = () => {
    fetchRecentLookups()
      .then((rows) => {
        setRecent(rows);
        setRecentError(null);
      })
      .catch((err: Error) => setRecentError(err.message));
  };

  useEffect(loadRecent, []);

  const runSearch = async (term: string) => {
    setSearching(true);
    setError(null);
    try {
      const response = await lookupThreat(term);
      setResult(response);
      loadRecent();
    } catch (err) {
      setResult(null);
      setError(err instanceof Error ? err.message : 'The lookup failed.');
    } finally {
      setSearching(false);
    }
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const term = query.trim();
    if (term.length < 2) {
      setError('Enter a CVE ID or a keyword of at least two characters.');
      return;
    }
    void runSearch(term);
  };

  const pickRecent = (term: string) => {
    setQuery(term);
    void runSearch(term);
  };

  return (
    <Card title="Vulnerability lookup" subtitle="Search the NVD database by CVE ID (CVE-2024-3094) or by product keyword">
      <form onSubmit={handleSubmit} className="flex flex-col gap-3 sm:flex-row">
        <label className="relative flex-1">
          <span className="sr-only">CVE ID or keyword</span>
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="CVE-2024-3094 or nginx"
            maxLength={100}
            className="input-base w-full pl-10"
          />
        </label>
        <button type="submit" disabled={searching} className="btn-primary justify-center disabled:opacity-60">
          {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          {searching ? 'Searching' : 'Search'}
        </button>
      </form>

      {error && <p className="mt-3 text-sm text-critical">{error}</p>}

      <div className="mt-5">
        {result && result.items.length === 0 && <EmptyState message={`No NVD records matched "${result.query}".`} />}
        {result && result.items.length > 0 && (
          <>
            <p className="mb-2 text-xs text-muted">{result.items.length} record(s) for "{result.query}", highest CVSS first</p>
            <ul className="divide-y divide-white/5">
              {result.items.map((cve) => (
                <CveRow key={cve.id} cve={cve} />
              ))}
            </ul>
          </>
        )}
      </div>

      <div className="mt-6 border-t border-white/5 pt-5">
        <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted">Recent lookups</h3>
        {recentError ? (
          <p className="text-sm text-muted">{recentError}</p>
        ) : recent.length === 0 ? (
          <p className="text-sm text-muted">No lookups yet. Your searches will appear here.</p>
        ) : (
          <ul className="flex flex-wrap gap-2">
            {recent.map((row) => (
              <li key={row.id}>
                <button
                  type="button"
                  onClick={() => pickRecent(row.query)}
                  title={`${formatDate(row.created_at)} - ${row.match_count} result(s)`}
                  className="rounded-full border border-white/10 bg-secondary px-3 py-1.5 font-mono text-xs text-muted transition hover:border-primary/40 hover:text-white"
                >
                  {row.query}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Card>
  );
}
