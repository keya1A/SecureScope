import { ExternalLink } from 'lucide-react';
import { SEVERITY_COLORS } from '@/components/ui';
import type { CveItem } from '@/types/threat';
import { formatDate } from '@/utils/report';
import type { Severity } from '@/types/scan';

const CVSS_TO_SEVERITY: Record<string, Severity> = {
  CRITICAL: 'Critical',
  HIGH: 'High',
  MEDIUM: 'Medium',
  LOW: 'Low',
};

export default function CveRow({ cve }: { cve: CveItem }) {
  const severity = CVSS_TO_SEVERITY[cve.severity];
  const color = severity ? SEVERITY_COLORS[severity] : '#A1A1AA';
  const detailUrl = cve.references[0];

  return (
    <li className="py-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-mono text-sm font-semibold">{cve.id}</span>
        <span
          className="rounded-full px-2.5 py-0.5 text-xs font-semibold tabular-nums"
          style={{ color, backgroundColor: `${color}1f`, border: `1px solid ${color}55` }}
        >
          {cve.cvss !== null ? `CVSS ${cve.cvss.toFixed(1)}` : 'CVSS n/a'} {cve.severity !== 'UNKNOWN' ? cve.severity : ''}
        </span>
        {cve.kev && (
          <span className="rounded-full border border-critical/40 bg-critical/15 px-2.5 py-0.5 text-xs font-semibold text-critical">
            Exploited in the wild
          </span>
        )}
      </div>
      <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-muted">{cve.description}</p>
      <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted">
        {cve.published && <span>Published {formatDate(cve.published)}</span>}
        {detailUrl && (
          <a href={detailUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-primary hover:underline">
            Source <ExternalLink className="h-3 w-3" />
          </a>
        )}
      </div>
    </li>
  );
}
