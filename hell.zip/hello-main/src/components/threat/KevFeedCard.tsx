import { Card, EmptyState } from '@/components/ui';
import { formatDate } from '@/utils/report';
import type { KevItem } from '@/types/threat';

interface KevFeedCardProps {
  total: number;
  items: KevItem[];
  error: string | null;
}

export default function KevFeedCard({ total, items, error }: KevFeedCardProps) {
  return (
    <Card
      title="Known exploited vulnerabilities"
      subtitle={error ? 'CISA catalog unavailable' : `${total.toLocaleString()} entries in the CISA catalog, newest first`}
    >
      {error ? (
        <EmptyState message={`The CISA catalog could not be loaded: ${error}`} />
      ) : items.length === 0 ? (
        <EmptyState message="No entries were returned by the CISA catalog." />
      ) : (
        <ul className="divide-y divide-white/5">
          {items.map((item) => (
            <li key={item.id} className="py-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-sm font-semibold">{item.id}</span>
                {item.ransomware && (
                  <span className="rounded-full border border-critical/40 bg-critical/15 px-2.5 py-0.5 text-xs font-semibold text-critical">
                    Ransomware
                  </span>
                )}
              </div>
              <p className="mt-1 text-sm">{item.vendor} {item.product}: {item.name}</p>
              <p className="mt-2 text-xs leading-relaxed text-muted">{item.requiredAction}</p>
              <p className="mt-2 text-xs text-muted">
                Added {formatDate(item.dateAdded)} - Federal due date {formatDate(item.dueDate)}
              </p>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
