import { Card, EmptyState } from '@/components/ui';
import CveRow from '@/components/threat/CveRow';
import type { CveItem } from '@/types/threat';

interface AdvisoryCardProps {
  windowDays: number;
  items: CveItem[];
  error: string | null;
}

export default function AdvisoryCard({ windowDays, items, error }: AdvisoryCardProps) {
  return (
    <Card title="Critical advisories" subtitle={`Newly published CVSS v3 critical vulnerabilities from the last ${windowDays} days`}>
      {error ? (
        <EmptyState message={`Advisories could not be loaded: ${error}`} />
      ) : items.length === 0 ? (
        <EmptyState message={`No critical vulnerabilities were published in the last ${windowDays} days.`} />
      ) : (
        <ul className="divide-y divide-white/5">
          {items.map((cve) => (
            <CveRow key={cve.id} cve={cve} />
          ))}
        </ul>
      )}
    </Card>
  );
}
