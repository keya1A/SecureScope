import { ShieldCheck } from 'lucide-react';

export default function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-dark shadow-glow">
        <ShieldCheck className="h-5 w-5 text-white" strokeWidth={2.2} />
      </div>
      {!compact && <span className="text-lg font-bold tracking-tight">Secure<span className="text-primary">Scope</span></span>}
    </div>
  );
}
