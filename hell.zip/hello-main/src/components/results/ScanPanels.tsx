import { CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import { Card, EmptyState, StatusBadge } from '@/components/ui';
import { formatDate } from '@/utils/report';
import type { ScanResult } from '@/types/scan';

type Result = ScanResult;

export function HeaderPanel({ http }: { http: Result['http'] }) {
  if (http.headers.length === 0) {
    return <EmptyState message="No HTTPS response was received, so security headers could not be analyzed." />;
  }
  const missing = http.headers.filter((h) => h.status === 'missing').length;
  return (
    <div className="grid gap-6 xl:grid-cols-2">
      <Card title="Security headers" subtitle={`${http.headers.length - missing} of ${http.headers.length} headers present and acceptable`}>
        <ul className="space-y-3">
          {http.headers.map((h) => (
            <li key={h.name} className="rounded-xl border border-white/5 bg-secondary p-4">
              <div className="flex items-center justify-between gap-3">
                <span className="font-mono text-sm">{h.name}</span>
                <StatusBadge status={h.status} />
              </div>
              <p className="mt-2 text-sm text-muted">{h.impact}</p>
              {h.status !== 'secure' && <p className="mt-2 text-sm text-warning">Fix: {h.recommendation}</p>}
              {h.value && <p className="mt-2 truncate font-mono text-xs text-muted/80" title={h.value}>{h.value}</p>}
            </li>
          ))}
        </ul>
      </Card>
      <Card title="Cookie security" subtitle="Attributes checked on every cookie the site sets">
        {http.cookies.length === 0 ? (
          <EmptyState message="The site did not set any cookies on the initial request." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-xs uppercase tracking-wider text-muted">
                <tr>
                  <th className="pb-3 font-medium">Cookie</th>
                  <th className="pb-3 font-medium">Secure</th>
                  <th className="pb-3 font-medium">HttpOnly</th>
                  <th className="pb-3 font-medium">SameSite</th>
                </tr>
              </thead>
              <tbody>
                {http.cookies.map((c) => (
                  <tr key={c.name} className="border-t border-white/5">
                    <td className="py-3 font-mono text-xs">{c.name}</td>
                    <td className="py-3"><Flag ok={c.secure} /></td>
                    <td className="py-3"><Flag ok={c.httpOnly} /></td>
                    <td className="py-3">{c.sameSite ? <span className="text-success">{c.sameSite}</span> : <span className="text-warning">Not set</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
          <Stat label="Server banner" value={http.serverBanner ?? 'Hidden'} />
          <Stat label="X-Powered-By" value={http.poweredBy ?? 'Hidden'} />
          <Stat label="HTTP to HTTPS redirect" value={http.httpRedirectsToHttps === null ? 'Not tested' : http.httpRedirectsToHttps ? 'Yes' : 'No'} />
          <Stat label="Final URL" value={http.finalUrl ?? 'n/a'} />
        </div>
      </Card>
    </div>
  );
}

export function TlsPanel({ tls }: { tls: Result['tls'] }) {
  const countdownColor = tls.daysRemaining === null ? 'text-muted' : tls.daysRemaining < 0 ? 'text-critical' : tls.daysRemaining < 30 ? 'text-warning' : 'text-success';
  const chainLabel = tls.chainValid === null ? 'Not determined' : tls.chainValid ? 'Trusted chain' : 'Validation failed';
  return (
    <div className="grid gap-6 xl:grid-cols-3">
      <Card title="Certificate" subtitle={tls.source} className="xl:col-span-2">
        {!tls.found ? (
          <EmptyState message={tls.note} />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            <Stat label="Subject" value={tls.subject ?? 'n/a'} />
            <Stat label="Issuer" value={tls.issuer ?? 'n/a'} />
            <Stat label="Valid from" value={tls.validFrom ? formatDate(tls.validFrom) : 'n/a'} />
            <Stat label="Valid until" value={tls.validUntil ? formatDate(tls.validUntil) : 'n/a'} />
            <Stat label="TLS version" value={tls.tlsVersion ?? 'Not measured'} />
            <Stat label="Certificate chain" value={chainLabel} />
          </div>
        )}
        <p className="mt-5 text-xs leading-relaxed text-muted">{tls.note}</p>
      </Card>
      <Card title="Expiration countdown">
        <div className="flex h-full flex-col items-center justify-center py-4">
          <span className={`text-5xl font-bold tabular-nums ${countdownColor}`}>
            {tls.daysRemaining === null ? '--' : Math.abs(tls.daysRemaining)}
          </span>
          <span className="mt-2 text-sm text-muted">
            {tls.daysRemaining === null ? 'No expiry data' : tls.daysRemaining < 0 ? 'days since expiry' : 'days remaining'}
          </span>
          <div className="mt-5"><StatusBadge status={tls.status} /></div>
        </div>
      </Card>
    </div>
  );
}

export function DnsPanel({ dns, whois }: { dns: Result['dns']; whois: Result['whois'] }) {
  const { records, security } = dns;
  const checks = [
    { label: 'SPF', ok: security.spf.present && security.spf.policy !== '+all', detail: security.spf.policy ?? 'Not published' },
    { label: 'DMARC', ok: security.dmarc.present && security.dmarc.policy !== 'none', detail: security.dmarc.policy ? `p=${security.dmarc.policy}` : 'Not published' },
    { label: 'DKIM', ok: security.dkim.discovered, detail: security.dkim.discovered ? security.dkim.selectors.join(', ') : 'Not discoverable' },
    { label: 'DNSSEC', ok: security.dnssec === 'signed-validated', detail: security.dnssec },
  ];
  return (
    <div className="grid gap-6 xl:grid-cols-2">
      <Card title="Email and DNS security">
        <div className="grid grid-cols-2 gap-3">
          {checks.map((c) => (
            <div key={c.label} className="flex items-center gap-3 rounded-xl border border-white/5 bg-secondary p-4">
              {c.ok ? <CheckCircle2 className="h-5 w-5 text-success" /> : <AlertTriangle className="h-5 w-5 text-warning" />}
              <div>
                <p className="text-sm font-semibold">{c.label}</p>
                <p className="text-xs text-muted">{c.detail}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 space-y-2">
          {(Object.keys(records) as (keyof typeof records)[]).map((type) => (
            <div key={type} className="grid grid-cols-[72px_1fr] gap-3 border-t border-white/5 pt-2 text-sm">
              <span className="font-mono text-xs text-primary">{type}</span>
              <span className="break-all font-mono text-xs text-muted">{records[type].length ? records[type].join('  |  ') : 'none'}</span>
            </div>
          ))}
        </div>
      </Card>
      <Card title="WHOIS" subtitle={whois.note}>
        {!whois.available ? (
          <EmptyState message="Registration data could not be retrieved." />
        ) : (
          <div className="grid grid-cols-2 gap-4">
            <Stat label="Registrar" value={whois.registrar ?? 'Not disclosed'} />
            <Stat label="Domain age" value={whois.ageDays === null ? 'n/a' : `${Math.floor(whois.ageDays / 365)} yr ${whois.ageDays % 365} d`} />
            <Stat label="Registered" value={whois.registeredOn ? formatDate(whois.registeredOn) : 'n/a'} />
            <Stat label="Expires" value={whois.expiresOn ? formatDate(whois.expiresOn) : 'n/a'} />
            <div className="col-span-2">
              <Stat label="Name servers" value={whois.nameServers.join(', ') || 'n/a'} />
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}

export function IntelPanel({ technologies, cves, cveNotes }: { technologies: Result['technologies']; cves: Result['cves']; cveNotes: string[] }) {
  return (
    <div className="grid gap-6">
      <Card title="Detected technologies">
        {technologies.length === 0 ? (
          <EmptyState message="No technology signatures were visible in the response." />
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {technologies.map((t) => (
              <div key={t.name} className="rounded-xl border border-white/5 bg-secondary p-4">
                <p className="text-xs uppercase tracking-wider text-muted">{t.category}</p>
                <p className="mt-1 font-semibold">{t.name} {t.version && <span className="font-mono text-sm text-primary">{t.version}</span>}</p>
                <p className="mt-2 text-xs text-muted">{t.evidence}</p>
              </div>
            ))}
          </div>
        )}
      </Card>
      <Card title="CVE correlation" subtitle="Versions are matched against NVD configuration ranges before a CVE is reported">
        {cveNotes.length > 0 && (
          <ul className="mb-5 space-y-1 text-xs text-muted">
            {cveNotes.map((note) => <li key={note}>- {note}</li>)}
          </ul>
        )}
        {cves.length === 0 ? (
          <EmptyState message="No applicable CVE records were correlated for the detected versions." />
        ) : (
          <ul className="space-y-3">
            {cves.map((cve) => (
              <li key={cve.id} className="rounded-xl border border-white/5 bg-secondary p-4">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="font-mono text-sm font-semibold">{cve.id}</span>
                  <span className="rounded-md bg-white/5 px-2 py-0.5 text-xs text-muted">CVSS {cve.cvss ?? 'n/a'} {cve.severity}</span>
                  {cve.kev ? (
                    <span className="inline-flex items-center gap-1 rounded-md bg-critical/15 px-2 py-0.5 text-xs font-semibold text-critical">
                      <XCircle className="h-3.5 w-3.5" /> Known exploited (CISA KEV)
                    </span>
                  ) : (
                    <span className="text-xs text-muted">Not in CISA KEV</span>
                  )}
                </div>
                <p className="mt-2 text-xs text-muted">Affects {cve.technology} {cve.version} ({cve.affectedProduct})</p>
                <p className="mt-2 text-sm leading-relaxed text-white/85">{cve.description}</p>
                <div className="mt-3 flex flex-wrap gap-3">
                  {cve.references.map((ref) => (
                    <a key={ref} href={ref} target="_blank" rel="noreferrer" className="truncate text-xs text-primary hover:underline">{ref}</a>
                  ))}
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Flag({ ok }: { ok: boolean }) {
  return ok ? <CheckCircle2 className="h-4 w-4 text-success" /> : <XCircle className="h-4 w-4 text-critical" />;
}

export function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-secondary p-4">
      <p className="text-xs uppercase tracking-wider text-muted">{label}</p>
      <p className="mt-1 break-words text-sm font-medium">{value}</p>
    </div>
  );
}
