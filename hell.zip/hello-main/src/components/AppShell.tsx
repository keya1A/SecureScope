import { useState } from 'react';
import { NavLink, Outlet, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { LayoutDashboard, ScanSearch, ShieldAlert, Radar, FileText, Info, Menu, X } from 'lucide-react';
import Logo from '@/components/Logo';

const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/new-scan', label: 'New Security Scan', icon: ScanSearch },
  { to: '/findings', label: 'Security Findings', icon: ShieldAlert },
  { to: '/threat-intel', label: 'Threat Intelligence', icon: Radar },
  { to: '/reports', label: 'Reports', icon: FileText },
  { to: '/about', label: 'About Project', icon: Info },
];

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <div className="flex h-full flex-col">
      <Link to="/" className="px-6 py-6">
        <Logo />
      </Link>
      <nav className="flex flex-1 flex-col gap-1 px-3">
        {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            onClick={onNavigate}
            className={({ isActive }) =>
              `group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                isActive ? 'bg-primary/10 text-white' : 'text-muted hover:bg-white/5 hover:text-white'
              }`
            }
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <motion.span layoutId="sidebar-indicator" className="absolute left-0 h-6 w-1 rounded-r-full bg-primary shadow-glow" />
                )}
                <Icon className={`h-4 w-4 ${isActive ? 'text-primary' : ''}`} />
                {label}
              </>
            )}
          </NavLink>
        ))}
      </nav>
      <div className="m-3 rounded-xl border border-white/5 bg-secondary p-4 text-xs leading-relaxed text-muted">
        Only scan domains you own or have written permission to assess.
      </div>
    </div>
  );
}

export default function AppShell() {
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <aside className="no-print fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-white/5 bg-secondary lg:block">
        <SidebarContent />
      </aside>

      <header className="no-print sticky top-0 z-20 flex items-center justify-between border-b border-white/5 bg-background/80 px-4 py-3 backdrop-blur lg:hidden">
        <Logo />
        <button onClick={() => setOpen(true)} className="rounded-lg p-2 text-muted hover:text-white" aria-label="Open navigation">
          <Menu className="h-5 w-5" />
        </button>
      </header>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              className="fixed inset-0 z-40 bg-black/70 lg:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
            />
            <motion.aside
              className="fixed inset-y-0 left-0 z-50 w-64 border-r border-white/5 bg-secondary lg:hidden"
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', stiffness: 320, damping: 34 }}
            >
              <button onClick={() => setOpen(false)} className="absolute right-4 top-6 text-muted hover:text-white" aria-label="Close navigation">
                <X className="h-5 w-5" />
              </button>
              <SidebarContent onNavigate={() => setOpen(false)} />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <main className="px-4 py-8 sm:px-8 lg:ml-64 lg:px-10">
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
          <Outlet />
        </motion.div>
      </main>
    </div>
  );
}
