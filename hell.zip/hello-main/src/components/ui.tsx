import { motion } from 'framer-motion';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';
import type { ReactNode } from 'react';
import type { RiskCategory, Severity } from '@/types/scan';

export const SEVERITY_COLORS: Record<Severity, string> = {
  Critical: '#EF4444',
  High: '#E63946',
  Medium: '#F59E0B',
  Low: '#A1A1AA',
  Informational: '#525252',
};

export const RISK_COLORS: Record<RiskCategory, string> = {
  Low: '#22C55E',
  Medium: '#F59E0B',
  High: '#E63946',
  Critical: '#EF4444',
};

export function Card({ title, subtitle, action, children, className = '' }: {
  title?: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className={`glass-card p-6 ${className}`}
    >
      {(title || action) && (
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            {title && <h2 className="text-base font-semibold">{title}</h2>}
            {subtitle && <p className="mt-1 text-sm text-muted">{subtitle}</p>}
          </div>
          {action}
        </div>
      )}
      {children}
    </motion.section>
  );
}

export function SeverityBadge({ severity }: { severity: Severity }) {
  const color = SEVERITY_COLORS[severity];
  return (
    <span
      className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold"
      style={{ color, backgroundColor: `${color}1f`, border: `1px solid ${color}55` }}
    >
      {severity}
    </span>
  );
}

export function StatusBadge({ status }: { status: 'ok' | 'warning' | 'error' | 'valid' | 'expiring' | 'expired' | 'unknown' | 'secure' | 'weak' | 'missing' }) {
  const map: Record<string, { label: string; color: string }> = {
    ok: { label: 'OK', color: '#22C55E' },
    secure: { label: 'Secure', color: '#22C55E' },
    valid: { label: 'Valid', color: '#22C55E' },
    warning: { label: 'Warning', color: '#F59E0B' },
    weak: { label: 'Weak', color: '#F59E0B' },
    expiring: { label: 'Expiring', color: '#F59E0B' },
    unknown: { label: 'Unknown', color: '#A1A1AA' },
    error: { label: 'Error', color: '#EF4444' },
    missing: { label: 'Missing', color: '#EF4444' },
    expired: { label: 'Expired', color: '#EF4444' },
  };
  const { label, color } = map[status];
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold" style={{ color }}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: color, boxShadow: `0 0 8px ${color}` }} />
      {label}
    </span>
  );
}

export function RiskGauge({ score, category }: { score: number; category: RiskCategory }) {
  const radius = 62;
  const circumference = 2 * Math.PI * radius;
  const color = RISK_COLORS[category];
  return (
    <div className="relative flex h-44 w-44 items-center justify-center">
      <svg viewBox="0 0 160 160" className="h-full w-full -rotate-90">
        <circle cx="80" cy="80" r={radius} fill="none" stroke="#262626" strokeWidth="12" />
        <motion.circle
          cx="80"
          cy="80"
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: circumference * (1 - score / 100) }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
          style={{ filter: `drop-shadow(0 0 8px ${color}88)` }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-4xl font-bold tabular-nums">{score}</span>
        <span className="text-xs text-muted">of 100</span>
      </div>
    </div>
  );
}

export function SeverityChart({ counts }: { counts: Record<Severity, number> }) {
  const data = (Object.keys(SEVERITY_COLORS) as Severity[]).map((severity) => ({ severity, count: counts[severity] }));
  return (
    <div className="h-56 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
          <XAxis dataKey="severity" tick={{ fill: '#A1A1AA', fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis allowDecimals={false} tick={{ fill: '#A1A1AA', fontSize: 11 }} axisLine={false} tickLine={false} />
          <Tooltip
            cursor={{ fill: 'rgba(255,255,255,0.04)' }}
            contentStyle={{ background: '#111111', border: '1px solid #262626', borderRadius: 12, color: '#fff' }}
          />
          <Bar dataKey="count" radius={[6, 6, 0, 0]} animationDuration={900}>
            {data.map((entry) => (
              <Cell key={entry.severity} fill={SEVERITY_COLORS[entry.severity]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function EmptyState({ message }: { message: string }) {
  return <p className="rounded-xl border border-dashed border-white/10 p-6 text-center text-sm text-muted">{message}</p>;
}
