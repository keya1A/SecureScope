# Local FastAPI integration

The React app now starts scans through `VITE_SCAN_API_URL` (FastAPI), while it reads scan history/results from Supabase. The FastAPI process writes completed scan rows to the existing `scans` table using the server-only Supabase service-role key.

1. Apply `supabase/migrations/20261110092641_create_scans_table.sql` to your Supabase project (if it has not already been applied).
2. Copy root `.env.example` to `.env` and fill in the Supabase project URL and anon key.
3. Copy `backend/.env.example` to `backend/.env` and fill in the same Supabase URL plus the **service_role** key.
4. Start FastAPI from the `backend` folder using the commands in `backend/README.md`.
5. Start Vite from the project root with `npm run dev`.
6. Check `http://127.0.0.1:8000/health`, then run a scan only against a domain you own or are authorized to test.

The threat-intel page remains wired to the existing Supabase Edge Function. This local FastAPI integration replaces the scan execution endpoint only; it does not automatically deploy the threat-intel function.
