/*
# Create scans table

Stores every security assessment run by SecureScope so results can be reopened,
listed on the dashboard, and exported from the reports page.

1. New Tables
- `scans`
  - `id` (uuid, primary key)
  - `domain` (text, the authorized target hostname, lowercase)
  - `status` (text, 'completed' or 'failed')
  - `risk_score` (integer, 0-100, deterministic weighted score; null when failed)
  - `risk_category` (text, Low / Medium / High / Critical; null when failed)
  - `result` (jsonb, full assessment payload: modules, findings, CVEs, timings)
  - `duration_ms` (integer, wall-clock scan duration)
  - `created_at` (timestamptz, scan start time)

2. Security
- RLS enabled. No sign-in exists in this app, so the anon and authenticated roles
  get SELECT only. Scans are written exclusively by the scan-domain edge function,
  which uses the service role and bypasses RLS.
- No INSERT/UPDATE/DELETE grant is given to anon or authenticated, so browsers
  cannot forge or alter scan records.

3. Indexes
- Index on `created_at` for the newest-first dashboard listing.
- Index on `domain` for per-target history lookups.
*/

CREATE TABLE IF NOT EXISTS scans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain text NOT NULL,
  status text NOT NULL CHECK (status IN ('completed', 'failed')),
  risk_score integer CHECK (risk_score IS NULL OR (risk_score >= 0 AND risk_score <= 100)),
  risk_category text CHECK (risk_category IS NULL OR risk_category IN ('Low', 'Medium', 'High', 'Critical')),
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  duration_ms integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS scans_created_at_idx ON scans (created_at DESC);
CREATE INDEX IF NOT EXISTS scans_domain_idx ON scans (domain);

ALTER TABLE scans ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON scans TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON scans TO service_role;

DROP POLICY IF EXISTS "anon_select_scans" ON scans;
CREATE POLICY "anon_select_scans" ON scans FOR SELECT
  TO anon, authenticated USING (true);
