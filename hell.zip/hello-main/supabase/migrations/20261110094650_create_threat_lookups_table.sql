/*
# Create threat_lookups table

Stores every vulnerability lookup made from the Threat Intelligence page so the
page can list recent searches.

1. New Tables
- `threat_lookups`
  - `id` (uuid, primary key)
  - `query` (text, the CVE ID or keyword the visitor searched, 2-100 characters)
  - `kind` (text, 'cve' or 'keyword')
  - `match_count` (integer, number of NVD records returned)
  - `created_at` (timestamptz, when the lookup ran)

2. Security
- RLS enabled. The app has no sign-in, so anon and authenticated roles get SELECT only.
- Rows are written exclusively by the threat-intel edge function using the service role.
- Browsers cannot insert, alter, or delete lookup records.

3. Indexes
- Index on `created_at` for the newest-first recent lookups listing.
*/

CREATE TABLE IF NOT EXISTS threat_lookups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  query text NOT NULL CHECK (char_length(query) BETWEEN 2 AND 100),
  kind text NOT NULL CHECK (kind IN ('cve', 'keyword')),
  match_count integer NOT NULL DEFAULT 0 CHECK (match_count >= 0),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS threat_lookups_created_at_idx ON threat_lookups (created_at DESC);

ALTER TABLE threat_lookups ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON threat_lookups TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON threat_lookups TO service_role;

DROP POLICY IF EXISTS "anon_select_threat_lookups" ON threat_lookups;
CREATE POLICY "anon_select_threat_lookups" ON threat_lookups FOR SELECT
  TO anon, authenticated USING (true);
