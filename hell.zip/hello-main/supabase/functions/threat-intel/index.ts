import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const KEV_ENDPOINT = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json";
const NVD_ENDPOINT = "https://services.nvd.nist.gov/rest/json/cves/2.0";
const ADVISORY_WINDOW_DAYS = 14;
const ADVISORY_LIMIT = 12;
const LOOKUP_LIMIT = 10;
const KEV_RECENT_LIMIT = 15;
const CVE_PATTERN = /^CVE-\d{4}-\d{4,7}$/i;
const QUERY_PATTERN = /^[A-Za-z0-9 ._\-/+:]{2,100}$/;

interface KevEntry {
  cveID: string;
  vendorProject: string;
  product: string;
  vulnerabilityName: string;
  dateAdded: string;
  dueDate: string;
  requiredAction: string;
  knownRansomwareCampaignUse?: string;
}

interface KevItem {
  id: string;
  vendor: string;
  product: string;
  name: string;
  dateAdded: string;
  dueDate: string;
  requiredAction: string;
  ransomware: boolean;
}

interface NvdMetric {
  cvssData?: { baseScore?: number; baseSeverity?: string };
}

interface NvdCve {
  id: string;
  descriptions?: { lang: string; value: string }[];
  published?: string;
  references?: { url: string }[];
  metrics?: Record<string, NvdMetric[] | undefined>;
}

interface CveItem {
  id: string;
  description: string;
  cvss: number | null;
  severity: string;
  published: string;
  references: string[];
  kev: boolean;
}

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function fetchKev(): Promise<KevItem[]> {
  const response = await fetch(KEV_ENDPOINT, { signal: AbortSignal.timeout(15_000) });
  if (!response.ok) throw new Error(`CISA KEV catalog returned HTTP ${response.status}`);
  const data = (await response.json()) as { vulnerabilities?: KevEntry[] };
  return (data.vulnerabilities ?? [])
    .map((entry) => ({
      id: entry.cveID,
      vendor: entry.vendorProject,
      product: entry.product,
      name: entry.vulnerabilityName,
      dateAdded: entry.dateAdded,
      dueDate: entry.dueDate,
      requiredAction: entry.requiredAction,
      ransomware: entry.knownRansomwareCampaignUse === "Known",
    }))
    .sort((a, b) => b.dateAdded.localeCompare(a.dateAdded));
}

function cvssOf(cve: NvdCve): { score: number | null; severity: string } {
  const metric = cve.metrics?.cvssMetricV31?.[0] ?? cve.metrics?.cvssMetricV30?.[0] ?? cve.metrics?.cvssMetricV2?.[0];
  return {
    score: metric?.cvssData?.baseScore ?? null,
    severity: metric?.cvssData?.baseSeverity ?? "UNKNOWN",
  };
}

async function queryNvd(params: URLSearchParams): Promise<NvdCve[]> {
  const headers: Record<string, string> = {};
  const apiKey = Deno.env.get("NVD_API_KEY");
  if (apiKey) headers.apiKey = apiKey;

  const response = await fetch(`${NVD_ENDPOINT}?${params}`, {
    headers,
    signal: AbortSignal.timeout(20_000),
  });
  if (response.status === 403 || response.status === 429) {
    throw new Error("The NVD vulnerability database is rate limiting requests. Try again in a minute.");
  }
  if (!response.ok) throw new Error(`NVD returned HTTP ${response.status}`);
  const data = (await response.json()) as { vulnerabilities?: { cve: NvdCve }[] };
  return (data.vulnerabilities ?? []).map((entry) => entry.cve);
}

function toCveItem(cve: NvdCve, kevIds: Set<string>): CveItem {
  const cvss = cvssOf(cve);
  return {
    id: cve.id,
    description: cve.descriptions?.find((d) => d.lang === "en")?.value ?? "No description provided.",
    cvss: cvss.score,
    severity: cvss.severity,
    published: cve.published ?? "",
    references: (cve.references ?? []).slice(0, 3).map((ref) => ref.url),
    kev: kevIds.has(cve.id),
  };
}

async function loadFeed() {
  const windowEnd = new Date();
  const windowStart = new Date(windowEnd.getTime() - ADVISORY_WINDOW_DAYS * 24 * 60 * 60 * 1000);
  const advisoryParams = new URLSearchParams({
    cvssV3Severity: "CRITICAL",
    pubStartDate: windowStart.toISOString(),
    pubEndDate: windowEnd.toISOString(),
    resultsPerPage: String(ADVISORY_LIMIT),
  });

  const [kevResult, advisoryResult] = await Promise.allSettled([fetchKev(), queryNvd(advisoryParams)]);
  const kevCatalog = kevResult.status === "fulfilled" ? kevResult.value : [];
  const kevIds = new Set(kevCatalog.map((item) => item.id));

  return {
    fetchedAt: new Date().toISOString(),
    kev: {
      total: kevCatalog.length,
      recent: kevCatalog.slice(0, KEV_RECENT_LIMIT),
      error: kevResult.status === "rejected" ? errorMessage(kevResult.reason) : null,
    },
    advisories: {
      windowDays: ADVISORY_WINDOW_DAYS,
      items: advisoryResult.status === "fulfilled"
        ? advisoryResult.value.map((cve) => toCveItem(cve, kevIds))
        : [],
      error: advisoryResult.status === "rejected" ? errorMessage(advisoryResult.reason) : null,
    },
  };
}

async function runLookup(query: string) {
  const isCve = CVE_PATTERN.test(query);
  const params = new URLSearchParams(
    isCve ? { cveId: query.toUpperCase() } : { keywordSearch: query, resultsPerPage: String(LOOKUP_LIMIT) },
  );
  const [kevIds, cves] = await Promise.all([
    fetchKev().then((items) => new Set(items.map((item) => item.id))).catch(() => new Set<string>()),
    queryNvd(params),
  ]);
  const items = cves.slice(0, LOOKUP_LIMIT).map((cve) => toCveItem(cve, kevIds));
  items.sort((a, b) => (b.cvss ?? 0) - (a.cvss ?? 0));
  return { kind: isCve ? "cve" as const : "keyword" as const, items };
}

async function recordLookup(query: string, kind: "cve" | "keyword", matchCount: number) {
  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { error } = await admin.from("threat_lookups").insert({ query, kind, match_count: matchCount });
  if (error) console.error("threat_lookups insert failed", error);
}

function errorMessage(reason: unknown): string {
  return reason instanceof Error ? reason.message : "The source could not be reached.";
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });
  if (req.method !== "POST") return jsonResponse({ error: "Method not allowed." }, 405);

  try {
    const body = (await req.json().catch(() => null)) as { action?: unknown; query?: unknown } | null;

    if (body?.action === "feed") {
      return jsonResponse(await loadFeed());
    }

    if (body?.action === "lookup") {
      if (typeof body.query !== "string") return jsonResponse({ error: "Enter a CVE ID or keyword to search." }, 400);
      const query = body.query.trim();
      if (!QUERY_PATTERN.test(query)) {
        return jsonResponse({ error: "Use a CVE ID (for example CVE-2024-3094) or a keyword of 2-100 letters, numbers, or basic punctuation." }, 400);
      }
      const result = await runLookup(query);
      await recordLookup(query, result.kind, result.items.length);
      return jsonResponse({ query, ...result });
    }

    return jsonResponse({ error: "Unknown request." }, 400);
  } catch (error) {
    console.error("threat-intel failed", error);
    return jsonResponse({ error: errorMessage(error) }, 502);
  }
});
