import { analyzeDns } from "./dns.ts";
import { analyzeHeaders, parseCookies, probeHttpRedirect, probeHttps } from "./http.ts";
import { lookupCertificate } from "./tls.ts";
import { lookupWhois } from "./whois.ts";
import { detectTechnologies } from "./technology.ts";
import { correlateCves } from "./cve.ts";
import { buildFindings } from "./findings.ts";
import { computeRisk } from "./risk.ts";
import { isPrivateAddress } from "./validate.ts";
import type {
  DnsAnalysis,
  HttpAnalysis,
  LogEntry,
  ModuleId,
  ModuleResult,
  ModuleStatus,
  ScanResult,
  TlsInfo,
  WhoisInfo,
} from "./models.ts";

export class ScanRejectedError extends Error {}

const MODULE_ORDER: ModuleId[] = ["validation", "dns", "http", "tls", "whois", "technology", "cve", "findings", "risk", "report"];
const MODULE_LABELS: Record<ModuleId, string> = {
  validation: "Domain Validation",
  dns: "DNS Analysis",
  http: "HTTP Header Analysis",
  tls: "SSL/TLS Analysis",
  whois: "WHOIS Lookup",
  technology: "Technology Detection",
  cve: "CVE Correlation",
  findings: "Security Findings",
  risk: "Risk Scoring",
  report: "Report Generation",
};

type Outcome<T> = { ok: true; value: T } | { ok: false; error: string };

async function attempt<T>(task: () => Promise<T>): Promise<Outcome<T>> {
  try {
    return { ok: true, value: await task() };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}

class ScanRecorder {
  readonly modules: ModuleResult[] = [];
  readonly log: LogEntry[] = [];

  note(module: ModuleId, level: LogEntry["level"], message: string) {
    this.log.push({ time: new Date().toISOString(), module, level, message });
  }

  finish(module: ModuleId, status: ModuleStatus, message: string, startedAt: number) {
    this.modules.push({ id: module, label: MODULE_LABELS[module], status, message, durationMs: Date.now() - startedAt });
    const level = status === "error" ? "error" : status === "warning" ? "warn" : "info";
    this.note(module, level, message);
  }
}

function unavailableTls(chainValid: boolean | null, note: string): TlsInfo {
  return {
    source: "Certificate Transparency logs (crt.sh)",
    found: false,
    subject: null,
    issuer: null,
    validFrom: null,
    validUntil: null,
    daysRemaining: null,
    status: "unknown",
    chainValid,
    tlsVersion: null,
    note,
  };
}

function unavailableWhois(note: string): WhoisInfo {
  return {
    available: false,
    registrar: null,
    registeredOn: null,
    expiresOn: null,
    ageDays: null,
    daysUntilExpiry: null,
    nameServers: [],
    note,
  };
}

export async function runScan(domain: string): Promise<ScanResult> {
  const started = Date.now();
  const recorder = new ScanRecorder();

  let stepStart = Date.now();
  recorder.finish("validation", "ok", `${domain} passed format, scope, and private-address checks.`, stepStart);

  stepStart = Date.now();
  recorder.note("dns", "info", `Querying A, AAAA, CNAME, MX, NS, TXT, SOA, CAA records for ${domain}.`);
  const dnsOutcome = await attempt(() => analyzeDns(domain));
  if (!dnsOutcome.ok) throw new ScanRejectedError("DNS records could not be queried, so the scan cannot continue.");
  const dns: DnsAnalysis = dnsOutcome.value;

  const addresses = [...dns.records.A, ...dns.records.AAAA];
  if (addresses.length === 0) {
    throw new ScanRejectedError("The domain does not resolve to any address, so it cannot be scanned.");
  }
  if (addresses.some(isPrivateAddress)) {
    throw new ScanRejectedError("The domain resolves to a private or reserved address. Only public internet hosts can be scanned.");
  }
  const dnsMissing = [
    dns.security.spf.present ? null : "SPF",
    dns.security.dmarc.present ? null : "DMARC",
  ].filter(Boolean);
  recorder.finish(
    "dns",
    dnsMissing.length ? "warning" : "ok",
    dnsMissing.length ? `DNS resolved ${addresses.length} address(es). Missing: ${dnsMissing.join(", ")}.` : `DNS resolved ${addresses.length} address(es) with SPF and DMARC present.`,
    stepStart,
  );

  stepStart = Date.now();
  recorder.note("http", "info", `Requesting https://${domain}/ and checking HTTP to HTTPS redirect.`);
  const [probe, httpRedirectsToHttps] = await Promise.all([probeHttps(domain), probeHttpRedirect(domain)]);
  const http: HttpAnalysis = {
    ...probe.analysis,
    httpRedirectsToHttps,
    headers: probe.headers ? analyzeHeaders(probe.headers) : [],
    cookies: parseCookies(probe.setCookies),
  };
  const missingHeaders = http.headers.filter((header) => header.status !== "secure").length;
  if (!http.reachable) {
    recorder.finish("http", "error", `HTTPS request failed: ${probe.error}`, stepStart);
  } else {
    recorder.finish(
      "http",
      missingHeaders ? "warning" : "ok",
      `Received HTTP ${http.statusCode}. ${missingHeaders} header(s) missing or weak. ${http.cookies.length} cookie(s) inspected.`,
      stepStart,
    );
  }

  stepStart = Date.now();
  const chainValid = probe.analysis.reachable ? true : probe.chainError ? false : null;
  recorder.note("tls", "info", "Looking up the most recent certificate in public Certificate Transparency logs.");
  const [tlsOutcome, whoisOutcome] = await Promise.all([
    attempt(() => lookupCertificate(domain, chainValid)),
    attempt(() => lookupWhois(domain)),
  ]);
  const tls = tlsOutcome.ok ? tlsOutcome.value : unavailableTls(chainValid, `Certificate lookup failed: ${tlsOutcome.error}`);
  if (tls.status === "valid") {
    recorder.finish("tls", "ok", `Certificate valid for ${tls.daysRemaining} more day(s).`, stepStart);
  } else if (tls.status === "expiring") {
    recorder.finish("tls", "warning", `Certificate expires in ${tls.daysRemaining} day(s).`, stepStart);
  } else if (tls.status === "expired") {
    recorder.finish("tls", "error", `Certificate expired ${Math.abs(tls.daysRemaining ?? 0)} day(s) ago.`, stepStart);
  } else {
    recorder.finish("tls", "warning", tls.note, stepStart);
  }

  stepStart = Date.now();
  const whois = whoisOutcome.ok ? whoisOutcome.value : unavailableWhois(`WHOIS lookup failed: ${whoisOutcome.error}`);
  recorder.finish(
    "whois",
    whoisOutcome.ok ? "ok" : "warning",
    whoisOutcome.ok ? `Registrar: ${whois.registrar ?? "not disclosed"}.` : whois.note,
    stepStart,
  );

  stepStart = Date.now();
  const technologies = detectTechnologies(probe.headers, probe.setCookies, probe.html);
  recorder.finish(
    "technology",
    "ok",
    technologies.length ? `Identified ${technologies.length} technology signal(s).` : "No technology signatures were visible in the response.",
    stepStart,
  );

  stepStart = Date.now();
  const cveOutcome = await attempt(() => correlateCves(technologies));
  const correlation = cveOutcome.ok ? cveOutcome.value : { cves: [], notes: [], error: cveOutcome.error };
  const cveStatus: ModuleStatus = correlation.error ? "error" : correlation.notes.some((n) => n.includes("failed")) ? "warning" : "ok";
  recorder.finish("cve", cveStatus, `${correlation.cves.length} CVE record(s) correlated against detected versions.`, stepStart);

  stepStart = Date.now();
  const findings = buildFindings({ domain, http, tls, dns, whois, cves: correlation.cves });
  recorder.finish("findings", "ok", `${findings.length} finding(s) recorded.`, stepStart);

  stepStart = Date.now();
  const risk = computeRisk(findings, correlation.cves);
  recorder.finish("risk", "ok", `Weighted risk score ${risk.score} of 100 (${risk.category}).`, stepStart);

  stepStart = Date.now();
  recorder.finish("report", "ok", "Assessment payload assembled.", stepStart);

  recorder.modules.sort((a, b) => MODULE_ORDER.indexOf(a.id) - MODULE_ORDER.indexOf(b.id));

  return {
    domain,
    scannedAt: new Date(started).toISOString(),
    durationMs: Date.now() - started,
    modules: recorder.modules,
    log: recorder.log,
    http,
    tls,
    dns,
    whois,
    technologies,
    cves: correlation.cves,
    cveNotes: correlation.notes,
    findings,
    risk,
  };
}
