import type { CveHit, Technology } from "./models.ts";

const NVD_ENDPOINT = "https://services.nvd.nist.gov/rest/json/cves/2.0";
const KEV_ENDPOINT = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json";
const MAX_TECHNOLOGIES = 4;
const MAX_CVES_PER_TECH = 8;

const CPE_PRODUCTS: Record<string, { vendor: string; product: string }> = {
  Nginx: { vendor: "f5", product: "nginx" },
  Apache: { vendor: "apache", product: "http_server" },
  IIS: { vendor: "microsoft", product: "internet_information_services" },
  PHP: { vendor: "php", product: "php" },
  WordPress: { vendor: "wordpress", product: "wordpress" },
  Drupal: { vendor: "drupal", product: "drupal" },
  jQuery: { vendor: "jquery", product: "jquery" },
  Bootstrap: { vendor: "getbootstrap", product: "bootstrap" },
  Express: { vendor: "expressjs", product: "express" },
};

export interface CveCorrelation {
  cves: CveHit[];
  notes: string[];
  error: string | null;
}

interface NvdMetric {
  cvssData?: { baseScore?: number; baseSeverity?: string };
}

interface NvdCve {
  id: string;
  descriptions?: { lang: string; value: string }[];
  published?: string;
  references?: { url: string }[];
  metrics?: Record<string, NvdMetric[] | undefined>;
}

interface NvdResponse {
  vulnerabilities?: { cve: NvdCve }[];
}

function cvssOf(cve: NvdCve): { score: number | null; severity: string } {
  const metric = cve.metrics?.cvssMetricV31?.[0] ?? cve.metrics?.cvssMetricV30?.[0] ?? cve.metrics?.cvssMetricV2?.[0];
  return {
    score: metric?.cvssData?.baseScore ?? null,
    severity: metric?.cvssData?.baseSeverity ?? "UNKNOWN",
  };
}

async function loadKevIds(): Promise<Set<string>> {
  const response = await fetch(KEV_ENDPOINT, { signal: AbortSignal.timeout(15_000) });
  if (!response.ok) throw new Error(`CISA KEV catalog returned HTTP ${response.status}`);
  const data = (await response.json()) as { vulnerabilities?: { cveID: string }[] };
  return new Set((data.vulnerabilities ?? []).map((entry) => entry.cveID));
}

async function queryNvd(vendor: string, product: string, version: string, apiKey: string | undefined): Promise<NvdCve[]> {
  const params = new URLSearchParams({
    virtualMatchString: `cpe:2.3:a:${vendor}:${product}:${version}:*:*:*:*:*:*:*`,
    resultsPerPage: "50",
  });
  const response = await fetch(`${NVD_ENDPOINT}?${params}`, {
    headers: apiKey ? { apiKey } : {},
    signal: AbortSignal.timeout(20_000),
  });
  if (response.status === 403 || response.status === 429) {
    throw new Error("NVD rate limit reached. Try again in a minute or configure an NVD API key.");
  }
  if (!response.ok) throw new Error(`NVD returned HTTP ${response.status}`);
  const data = (await response.json()) as NvdResponse;
  return (data.vulnerabilities ?? []).map((entry) => entry.cve);
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export async function correlateCves(technologies: Technology[]): Promise<CveCorrelation> {
  const notes: string[] = [];
  const targets = technologies
    .filter((tech) => tech.version && CPE_PRODUCTS[tech.name])
    .slice(0, MAX_TECHNOLOGIES);

  if (targets.length === 0) {
    return { cves: [], notes: ["No technology with a known version was detected, so no CVE lookups were made."], error: null };
  }

  const apiKey = Deno.env.get("NVD_API_KEY") ?? undefined;
  const [kevResult] = await Promise.allSettled([loadKevIds()]);
  const kevIds = kevResult.status === "fulfilled" ? kevResult.value : null;
  if (!kevIds) notes.push("CISA KEV catalog could not be loaded, so known-exploitation status is unavailable.");

  const hits: CveHit[] = [];
  let error: string | null = null;

  for (const [index, tech] of targets.entries()) {
    const { vendor, product } = CPE_PRODUCTS[tech.name];
    if (index > 0 && !apiKey) await sleep(6500);
    try {
      const cves = await queryNvd(vendor, product, tech.version!, apiKey);
      notes.push(`${tech.name} ${tech.version}: NVD configuration ranges checked, ${cves.length} matching record(s).`);
      for (const cve of cves.slice(0, MAX_CVES_PER_TECH)) {
        const cvss = cvssOf(cve);
        hits.push({
          id: cve.id,
          description: cve.descriptions?.find((d) => d.lang === "en")?.value ?? "No description provided.",
          cvss: cvss.score,
          severity: cvss.severity,
          published: cve.published ?? "",
          technology: tech.name,
          version: tech.version!,
          affectedProduct: `${vendor}:${product}`,
          kev: kevIds?.has(cve.id) ?? false,
          references: (cve.references ?? []).slice(0, 3).map((ref) => ref.url),
        });
      }
    } catch (err) {
      error = err instanceof Error ? err.message : String(err);
      notes.push(`${tech.name} ${tech.version}: lookup failed. ${error}`);
    }
  }

  hits.sort((a, b) => (b.cvss ?? 0) - (a.cvss ?? 0));
  return { cves: hits, notes, error: hits.length === 0 && error ? error : null };
}
