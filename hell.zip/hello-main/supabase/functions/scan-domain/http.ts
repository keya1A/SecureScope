import type { CookieCheck, HeaderCheck, HttpAnalysis } from "./models.ts";

const USER_AGENT = "SecureScope-Scanner/1.0 (non-invasive authorized assessment)";
const MAX_BODY_BYTES = 300_000;

export interface HttpProbe {
  analysis: Omit<HttpAnalysis, "headers" | "cookies" | "httpRedirectsToHttps">;
  headers: Headers | null;
  setCookies: string[];
  html: string;
  chainError: boolean;
  error: string | null;
}

async function readBodyLimited(response: Response): Promise<string> {
  if (!response.body) return "";
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let received = 0;
  let text = "";
  while (received < MAX_BODY_BYTES) {
    const { done, value } = await reader.read();
    if (done) break;
    received += value.byteLength;
    text += decoder.decode(value, { stream: true });
  }
  await reader.cancel();
  return text;
}

export async function probeHttps(domain: string): Promise<HttpProbe> {
  const url = `https://${domain}/`;
  try {
    const response = await fetch(url, {
      redirect: "follow",
      headers: { "user-agent": USER_AGENT, accept: "text/html,*/*" },
      signal: AbortSignal.timeout(10_000),
    });
    const html = await readBodyLimited(response);
    return {
      analysis: {
        reachable: true,
        finalUrl: response.url,
        statusCode: response.status,
        serverBanner: response.headers.get("server"),
        poweredBy: response.headers.get("x-powered-by"),
      },
      headers: response.headers,
      setCookies: response.headers.getSetCookie(),
      html,
      chainError: false,
      error: null,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return {
      analysis: { reachable: false, finalUrl: null, statusCode: null, serverBanner: null, poweredBy: null },
      headers: null,
      setCookies: [],
      html: "",
      chainError: /certificate|tls|ssl/i.test(message),
      error: message,
    };
  }
}

export async function probeHttpRedirect(domain: string): Promise<boolean | null> {
  try {
    const response = await fetch(`http://${domain}/`, {
      redirect: "manual",
      headers: { "user-agent": USER_AGENT },
      signal: AbortSignal.timeout(6_000),
    });
    await response.body?.cancel();
    const location = response.headers.get("location") ?? "";
    return response.status >= 300 && response.status < 400 && location.startsWith("https://");
  } catch {
    return null;
  }
}

function headerCheck(
  name: string,
  value: string | null,
  evaluate: (v: string) => "secure" | "weak",
  impact: string,
  recommendation: string,
): HeaderCheck {
  if (value === null) return { name, present: false, value: null, status: "missing", impact, recommendation };
  return { name, present: true, value, status: evaluate(value), impact, recommendation };
}

export function analyzeHeaders(headers: Headers): HeaderCheck[] {
  const csp = headers.get("content-security-policy");
  const frameAncestors = csp !== null && /frame-ancestors/i.test(csp);
  const hsts = headers.get("strict-transport-security");
  const xfo = headers.get("x-frame-options");

  return [
    headerCheck(
      "Content-Security-Policy",
      csp,
      (v) => (/unsafe-(inline|eval)|script-src[^;]*\*/i.test(v) ? "weak" : "secure"),
      "Limits which scripts and resources can run. Without it, injected scripts (XSS) can read user data.",
      "Define a policy that allows only trusted sources and avoids 'unsafe-inline' and 'unsafe-eval'.",
    ),
    headerCheck(
      "Strict-Transport-Security",
      hsts,
      (v) => {
        const maxAge = Number(v.match(/max-age=(\d+)/i)?.[1] ?? 0);
        return maxAge >= 15_552_000 ? "secure" : "weak";
      },
      "Forces browsers to use HTTPS, blocking downgrade and SSL-stripping attacks.",
      "Send 'max-age=31536000; includeSubDomains' so browsers always connect over HTTPS.",
    ),
    headerCheck(
      "X-Content-Type-Options",
      headers.get("x-content-type-options"),
      (v) => (v.trim().toLowerCase() === "nosniff" ? "secure" : "weak"),
      "Stops browsers from guessing file types, which can turn uploads into executable scripts.",
      "Set the value to 'nosniff'.",
    ),
    headerCheck(
      "X-Frame-Options",
      xfo ?? (frameAncestors ? "frame-ancestors (via CSP)" : null),
      (v) => (/deny|sameorigin|frame-ancestors/i.test(v) ? "secure" : "weak"),
      "Prevents other sites from embedding this page in a frame, blocking clickjacking.",
      "Set 'X-Frame-Options: DENY' or use 'frame-ancestors' in the Content-Security-Policy.",
    ),
    headerCheck(
      "Referrer-Policy",
      headers.get("referrer-policy"),
      (v) => (/unsafe-url/i.test(v) ? "weak" : "secure"),
      "Controls how much URL information is sent to other sites when visitors click links.",
      "Use 'strict-origin-when-cross-origin' or a stricter value.",
    ),
    headerCheck(
      "Permissions-Policy",
      headers.get("permissions-policy"),
      () => "secure",
      "Restricts access to browser features such as camera, microphone, and geolocation.",
      "Disable unused browser features, for example 'camera=(), microphone=(), geolocation=()'.",
    ),
  ];
}

export function parseCookies(setCookies: string[]): CookieCheck[] {
  return setCookies.map((raw) => {
    const [pair, ...attributes] = raw.split(";").map((part) => part.trim());
    const name = pair.split("=")[0];
    const lowered = attributes.map((attribute) => attribute.toLowerCase());
    const sameSite = attributes.find((attribute) => attribute.toLowerCase().startsWith("samesite="));
    return {
      name,
      secure: lowered.includes("secure"),
      httpOnly: lowered.includes("httponly"),
      sameSite: sameSite ? sameSite.split("=")[1] : null,
    };
  });
}
