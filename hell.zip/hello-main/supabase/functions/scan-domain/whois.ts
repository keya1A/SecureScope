import type { WhoisInfo } from "./models.ts";

const DAY_MS = 86_400_000;

type VCardEntry = [string, object, string, unknown];

interface RdapEntity {
  roles?: string[];
  vcardArray?: [string, VCardEntry[]];
}

interface RdapResponse {
  events?: { eventAction: string; eventDate: string }[];
  nameservers?: { ldhName?: string }[];
  entities?: RdapEntity[];
}

function registrarName(entity: RdapEntity | undefined): string | null {
  const value = entity?.vcardArray?.[1]?.find((entry) => entry[0] === "fn")?.[3];
  return typeof value === "string" ? value : null;
}

export async function lookupWhois(domain: string): Promise<WhoisInfo> {
  const response = await fetch(`https://rdap.org/domain/${encodeURIComponent(domain)}`, {
    headers: { accept: "application/rdap+json" },
    redirect: "follow",
    signal: AbortSignal.timeout(12_000),
  });
  if (!response.ok) throw new Error(`Registration directory returned HTTP ${response.status}`);

  const data = (await response.json()) as RdapResponse;
  const eventDate = (action: string) => data.events?.find((event) => event.eventAction === action)?.eventDate ?? null;
  const registeredOn = eventDate("registration");
  const expiresOn = eventDate("expiration");
  const now = Date.now();

  return {
    available: true,
    registrar: registrarName(data.entities?.find((entity) => entity.roles?.includes("registrar"))),
    registeredOn,
    expiresOn,
    ageDays: registeredOn ? Math.floor((now - Date.parse(registeredOn)) / DAY_MS) : null,
    daysUntilExpiry: expiresOn ? Math.floor((Date.parse(expiresOn) - now) / DAY_MS) : null,
    nameServers: (data.nameservers ?? [])
      .map((ns) => ns.ldhName?.toLowerCase())
      .filter((ns): ns is string => Boolean(ns)),
    note: "Registration data is provided by the RDAP service at rdap.org.",
  };
}
