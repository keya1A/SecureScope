import type {
  CveHit,
  DnsAnalysis,
  Finding,
  HttpAnalysis,
  Severity,
  TlsInfo,
  WhoisInfo,
} from "./models.ts";

interface FindingInput {
  domain: string;
  http: HttpAnalysis;
  tls: TlsInfo;
  dns: DnsAnalysis;
  whois: WhoisInfo;
  cves: CveHit[];
}

function cveSeverity(score: number | null): Severity {
  if (score === null) return "Low";
  if (score >= 9) return "Critical";
  if (score >= 7) return "High";
  if (score >= 4) return "Medium";
  return "Low";
}

export function buildFindings(input: FindingInput): Finding[] {
  const { domain, http, tls, dns, whois, cves } = input;
  const findings: Finding[] = [];
  const add = (finding: Omit<Finding, "cveId"> & { cveId?: string | null }) =>
    findings.push({ cveId: null, ...finding });

  if (!http.reachable) {
    add({
      id: "https-unreachable",
      title: "HTTPS site could not be reached",
      severity: "High",
      module: "http",
      asset: `https://${domain}`,
      description: "The scanner could not complete an HTTPS request to the domain, so header and cookie checks could not run.",
      evidence: "HTTPS request failed or timed out.",
      impact: "Visitors may be unable to reach the site securely, or the certificate or server configuration is broken.",
      remediation: "Confirm the web server listens on port 443 with a valid, trusted certificate.",
      confidence: "Confirmed",
    });
  }

  if (http.reachable && http.httpRedirectsToHttps === false) {
    add({
      id: "no-http-redirect",
      title: "Plain HTTP does not redirect to HTTPS",
      severity: "Medium",
      module: "http",
      asset: `http://${domain}`,
      description: "Requests sent over unencrypted HTTP are not redirected to the HTTPS version of the site.",
      evidence: "HTTP request did not return a redirect to an https:// address.",
      impact: "First visits over HTTP can be intercepted or altered on untrusted networks.",
      remediation: "Configure the web server to permanently redirect (301) all HTTP requests to HTTPS.",
      confidence: "Confirmed",
    });
  }

  for (const header of http.headers) {
    if (header.status === "secure") continue;
    const missing = header.status === "missing";
    add({
      id: `header-${header.name.toLowerCase()}`,
      title: missing ? `Missing ${header.name} header` : `Weak ${header.name} header`,
      severity: headerSeverity(header.name, missing),
      module: "http",
      asset: `https://${domain}`,
      description: missing
        ? `The response does not include the ${header.name} security header.`
        : `The ${header.name} header is present but its value weakens the protection it provides.`,
      evidence: missing ? `${header.name}: (not present)` : `${header.name}: ${header.value}`,
      impact: header.impact,
      remediation: header.recommendation,
      confidence: "Confirmed",
    });
  }

  const insecureCookies = http.cookies.filter((c) => !c.secure);
  if (insecureCookies.length > 0) {
    add({
      id: "cookie-secure-flag",
      title: "Cookies sent without the Secure flag",
      severity: "Medium",
      module: "http",
      asset: `https://${domain}`,
      description: "Cookies can be sent over unencrypted connections because they lack the Secure attribute.",
      evidence: `Cookies: ${insecureCookies.map((c) => c.name).join(", ")}`,
      impact: "Session cookies may leak over plain HTTP, enabling account takeover on hostile networks.",
      remediation: "Add the Secure attribute to every cookie that is set over HTTPS.",
      confidence: "Confirmed",
    });
  }

  const scriptCookies = http.cookies.filter((c) => !c.httpOnly);
  if (scriptCookies.length > 0) {
    add({
      id: "cookie-httponly-flag",
      title: "Cookies readable by JavaScript",
      severity: "Medium",
      module: "http",
      asset: `https://${domain}`,
      description: "Cookies without the HttpOnly attribute can be read by page scripts, so any XSS flaw can steal them.",
      evidence: `Cookies: ${scriptCookies.map((c) => c.name).join(", ")}`,
      impact: "A single cross-site scripting bug could expose session tokens.",
      remediation: "Set HttpOnly on session and authentication cookies.",
      confidence: "Confirmed",
    });
  }

  const noSameSite = http.cookies.filter((c) => !c.sameSite);
  if (noSameSite.length > 0) {
    add({
      id: "cookie-samesite",
      title: "Cookies without a SameSite policy",
      severity: "Low",
      module: "http",
      asset: `https://${domain}`,
      description: "Cookies without SameSite can be attached to cross-site requests, which helps cross-site request forgery.",
      evidence: `Cookies: ${noSameSite.map((c) => c.name).join(", ")}`,
      impact: "Cross-site request forgery attacks become easier to mount.",
      remediation: "Set SameSite=Lax (or Strict where appropriate) on cookies.",
      confidence: "Confirmed",
    });
  }

  if (http.serverBanner && /\d/.test(http.serverBanner)) {
    add({
      id: "server-version-disclosure",
      title: "Server software version disclosed",
      severity: "Low",
      module: "http",
      asset: `https://${domain}`,
      description: "The Server header reveals the exact web server software and version.",
      evidence: `Server: ${http.serverBanner}`,
      impact: "Attackers can target known vulnerabilities for that exact version.",
      remediation: "Remove or genericize the Server header (for example ServerTokens Prod in Apache).",
      confidence: "Confirmed",
    });
  }

  if (http.poweredBy) {
    add({
      id: "x-powered-by-disclosure",
      title: "Framework disclosed in X-Powered-By header",
      severity: "Low",
      module: "http",
      asset: `https://${domain}`,
      description: "The X-Powered-By header reveals the underlying language or framework.",
      evidence: `X-Powered-By: ${http.poweredBy}`,
      impact: "Makes fingerprinting easier and narrows the attacker's search for exploits.",
      remediation: "Remove the X-Powered-By header in the application or web server configuration.",
      confidence: "Confirmed",
    });
  }

  if (tls.status === "expired") {
    add({
      id: "tls-expired",
      title: "TLS certificate has expired",
      severity: "Critical",
      module: "tls",
      asset: domain,
      description: "The most recent certificate issued for this domain is past its validity date.",
      evidence: `Valid until ${tls.validUntil} (${Math.abs(tls.daysRemaining ?? 0)} days ago)`,
      impact: "Browsers display security warnings and visitors may leave or be exposed to spoofing.",
      remediation: "Renew the certificate and deploy it to every server that terminates TLS for this domain.",
      confidence: "Likely",
    });
  } else if (tls.status === "expiring") {
    add({
      id: "tls-expiring",
      title: "TLS certificate expires soon",
      severity: "Medium",
      module: "tls",
      asset: domain,
      description: "The certificate expires within 30 days.",
      evidence: `Valid until ${tls.validUntil} (${tls.daysRemaining} days remaining)`,
      impact: "An expired certificate would break HTTPS for every visitor.",
      remediation: "Enable automatic renewal (for example ACME) and confirm the renewal succeeds.",
      confidence: "Likely",
    });
  }

  if (tls.chainValid === false) {
    add({
      id: "tls-chain-invalid",
      title: "Certificate chain failed validation",
      severity: "Critical",
      module: "tls",
      asset: domain,
      description: "The HTTPS connection failed certificate validation during the scan.",
      evidence: "TLS handshake reported a certificate error.",
      impact: "Connections may be untrusted or intercepted.",
      remediation: "Install the full intermediate chain with the certificate and verify it with an external TLS checker.",
      confidence: "Confirmed",
    });
  }

  if (!dns.security.spf.present) {
    add({
      id: "spf-missing",
      title: "No SPF record published",
      severity: "Medium",
      module: "dns",
      asset: domain,
      description: "The domain has no SPF record, so receiving mail servers cannot tell which servers may send mail for it.",
      evidence: "No TXT record beginning with v=spf1 at the domain apex.",
      impact: "Attackers can more easily spoof email from this domain.",
      remediation: "Publish an SPF record ending in -all or ~all listing your legitimate mail senders.",
      confidence: "Confirmed",
    });
  } else if (dns.security.spf.policy === "+all") {
    add({
      id: "spf-permissive",
      title: "SPF policy allows any sender",
      severity: "High",
      module: "dns",
      asset: domain,
      description: "The SPF record ends with +all, which authorizes every server on the internet to send mail for the domain.",
      evidence: dns.security.spf.record ?? "",
      impact: "Email spoofing and phishing from this domain is effectively unrestricted.",
      remediation: "Replace +all with -all (or ~all while testing).",
      confidence: "Confirmed",
    });
  }

  if (!dns.security.dmarc.present) {
    add({
      id: "dmarc-missing",
      title: "No DMARC policy published",
      severity: "Medium",
      module: "dns",
      asset: `_dmarc.${domain}`,
      description: "Without DMARC, receivers have no instruction for handling mail that fails authentication.",
      evidence: "No TXT record beginning with v=DMARC1 at _dmarc subdomain.",
      impact: "Spoofed messages claiming to come from the domain are not blocked.",
      remediation: "Publish a DMARC record, starting with p=none for monitoring and moving to p=quarantine or p=reject.",
      confidence: "Confirmed",
    });
  } else if (dns.security.dmarc.policy === "none") {
    add({
      id: "dmarc-monitor-only",
      title: "DMARC policy is monitor-only",
      severity: "Low",
      module: "dns",
      asset: `_dmarc.${domain}`,
      description: "DMARC is published with p=none, so spoofed mail is reported but still delivered.",
      evidence: dns.security.dmarc.record ?? "",
      impact: "Spoofed messages continue to reach inboxes.",
      remediation: "After reviewing reports, change the policy to p=quarantine or p=reject.",
      confidence: "Confirmed",
    });
  }

  if (!dns.security.dkim.discovered) {
    add({
      id: "dkim-not-discovered",
      title: "No DKIM selector discovered",
      severity: "Informational",
      module: "dns",
      asset: domain,
      description: "DKIM keys are published under selector names that cannot be listed. None of the common selectors returned a key.",
      evidence: "Checked selectors: default, google, selector1, selector2, k1, mail, dkim, s1, s2.",
      impact: "Mail signing could not be verified. A custom selector may still exist.",
      remediation: "Confirm DKIM signing is enabled with your mail provider.",
      confidence: "Inferred",
    });
  }

  if (dns.security.dnssec === "unsigned") {
    add({
      id: "dnssec-disabled",
      title: "DNSSEC not enabled",
      severity: "Low",
      module: "dns",
      asset: domain,
      description: "The zone is not signed with DNSSEC, so DNS answers cannot be verified as authentic.",
      evidence: "No DS record was published in the parent zone.",
      impact: "DNS responses can be forged through cache poisoning or on-path attacks.",
      remediation: "Enable DNSSEC at your DNS provider and publish the DS record at your registrar.",
      confidence: "Confirmed",
    });
  } else if (dns.security.dnssec === "signed-unvalidated") {
    add({
      id: "dnssec-validation-failed",
      title: "DNSSEC signature validation failed",
      severity: "High",
      module: "dns",
      asset: domain,
      description: "A DS record exists but the resolver could not validate the signatures.",
      evidence: "DS record present; resolver did not set the authenticated flag.",
      impact: "Resolvers that validate DNSSEC may refuse to answer for this domain.",
      remediation: "Check DNSSEC key rollover and DS records at the registrar.",
      confidence: "Likely",
    });
  }

  if (dns.records.CAA.length === 0) {
    add({
      id: "caa-missing",
      title: "No CAA record restricting certificate issuers",
      severity: "Informational",
      module: "dns",
      asset: domain,
      description: "No CAA record limits which certificate authorities may issue certificates for the domain.",
      evidence: "No CAA records returned.",
      impact: "Any certificate authority can issue certificates, slightly raising mis-issuance risk.",
      remediation: "Publish a CAA record naming only the certificate authorities you use.",
      confidence: "Confirmed",
    });
  }

  if (whois.daysUntilExpiry !== null && whois.daysUntilExpiry < 60) {
    add({
      id: "domain-expiry-soon",
      title: "Domain registration expires soon",
      severity: whois.daysUntilExpiry < 0 ? "Critical" : "Medium",
      module: "whois",
      asset: domain,
      description: "The domain registration is close to or past its expiry date.",
      evidence: `Expires ${whois.expiresOn} (${whois.daysUntilExpiry} days)`,
      impact: "An expired domain can be taken over, redirecting visitors and email.",
      remediation: "Renew the domain and enable auto-renewal with the registrar.",
      confidence: "Confirmed",
    });
  }

  for (const cve of cves) {
    const severity = cve.kev ? maxSeverity(cveSeverity(cve.cvss), "High") : cveSeverity(cve.cvss);
    add({
      id: `cve-${cve.id.toLowerCase()}`,
      title: `${cve.id} affects ${cve.technology} ${cve.version}`,
      severity,
      module: "cve",
      asset: cve.technology,
      description: cve.description.slice(0, 500),
      evidence: `Detected ${cve.technology} ${cve.version}; NVD configuration ranges match this version. CVSS ${cve.cvss ?? "n/a"}${cve.kev ? "; listed in CISA KEV (known exploited)" : ""}.`,
      impact: cve.kev
        ? "This vulnerability is confirmed exploited in the wild according to CISA."
        : "Exploitation may allow attackers to compromise the affected component.",
      remediation: `Upgrade ${cve.technology} to a version outside the affected range, and apply the vendor patch.`,
      confidence: "Likely",
      cveId: cve.id,
    });
  }

  return findings;
}

function headerSeverity(name: string, missing: boolean): Severity {
  if (name === "Strict-Transport-Security") return missing ? "High" : "Medium";
  if (name === "Content-Security-Policy" || name === "X-Frame-Options") return missing ? "Medium" : "Low";
  return "Low";
}

const SEVERITY_ORDER: Severity[] = ["Informational", "Low", "Medium", "High", "Critical"];

function maxSeverity(a: Severity, b: Severity): Severity {
  return SEVERITY_ORDER.indexOf(a) >= SEVERITY_ORDER.indexOf(b) ? a : b;
}
