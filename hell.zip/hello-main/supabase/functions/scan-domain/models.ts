export type Severity = "Critical" | "High" | "Medium" | "Low" | "Informational";
export type Confidence = "Confirmed" | "Likely" | "Inferred";
export type RiskCategory = "Low" | "Medium" | "High" | "Critical";
export type ModuleId = "validation" | "dns" | "http" | "tls" | "whois" | "technology" | "cve" | "findings" | "risk" | "report";
export type ModuleStatus = "ok" | "warning" | "error";

export interface LogEntry {
  time: string;
  module: ModuleId;
  level: "info" | "warn" | "error";
  message: string;
}

export interface ModuleResult {
  id: ModuleId;
  label: string;
  status: ModuleStatus;
  message: string;
  durationMs: number;
}

export interface Finding {
  id: string;
  title: string;
  severity: Severity;
  module: ModuleId;
  asset: string;
  description: string;
  evidence: string;
  impact: string;
  remediation: string;
  confidence: Confidence;
  cveId: string | null;
}

export interface HeaderCheck {
  name: string;
  present: boolean;
  value: string | null;
  status: "secure" | "weak" | "missing";
  impact: string;
  recommendation: string;
}

export interface CookieCheck {
  name: string;
  secure: boolean;
  httpOnly: boolean;
  sameSite: string | null;
}

export interface HttpAnalysis {
  reachable: boolean;
  finalUrl: string | null;
  statusCode: number | null;
  httpRedirectsToHttps: boolean | null;
  headers: HeaderCheck[];
  cookies: CookieCheck[];
  serverBanner: string | null;
  poweredBy: string | null;
}

export interface TlsInfo {
  source: string;
  found: boolean;
  subject: string | null;
  issuer: string | null;
  validFrom: string | null;
  validUntil: string | null;
  daysRemaining: number | null;
  status: "valid" | "expiring" | "expired" | "unknown";
  chainValid: boolean | null;
  tlsVersion: string | null;
  note: string;
}

export interface DnsRecords {
  A: string[];
  AAAA: string[];
  CNAME: string[];
  MX: string[];
  NS: string[];
  TXT: string[];
  SOA: string[];
  CAA: string[];
}

export interface DnsSecurity {
  spf: { present: boolean; record: string | null; policy: string | null };
  dmarc: { present: boolean; record: string | null; policy: string | null };
  dkim: { discovered: boolean; selectors: string[] };
  dnssec: "signed-validated" | "signed-unvalidated" | "unsigned";
}

export interface DnsAnalysis {
  records: DnsRecords;
  security: DnsSecurity;
}

export interface WhoisInfo {
  available: boolean;
  registrar: string | null;
  registeredOn: string | null;
  expiresOn: string | null;
  ageDays: number | null;
  daysUntilExpiry: number | null;
  nameServers: string[];
  note: string;
}

export interface Technology {
  name: string;
  category: "Web Server" | "CMS" | "Language" | "Framework" | "JavaScript Library";
  version: string | null;
  evidence: string;
}

export interface CveHit {
  id: string;
  description: string;
  cvss: number | null;
  severity: string;
  published: string;
  technology: string;
  version: string;
  affectedProduct: string;
  kev: boolean;
  references: string[];
}

export interface RiskFactor {
  label: string;
  points: number;
  maxPoints: number;
  detail: string;
}

export interface RiskAssessment {
  score: number;
  category: RiskCategory;
  factors: RiskFactor[];
  summary: string;
}

export interface ScanResult {
  domain: string;
  scannedAt: string;
  durationMs: number;
  modules: ModuleResult[];
  log: LogEntry[];
  http: HttpAnalysis;
  tls: TlsInfo;
  dns: DnsAnalysis;
  whois: WhoisInfo;
  technologies: Technology[];
  cves: CveHit[];
  cveNotes: string[];
  findings: Finding[];
  risk: RiskAssessment;
}
