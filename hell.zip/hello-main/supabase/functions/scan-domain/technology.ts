import type { Technology } from "./models.ts";

function addTechnology(list: Technology[], tech: Technology) {
  const existing = list.find((item) => item.name === tech.name);
  if (!existing) {
    list.push(tech);
    return;
  }
  if (!existing.version && tech.version) {
    existing.version = tech.version;
    existing.evidence = tech.evidence;
  }
}

function versionFrom(text: string): string | null {
  return text.match(/(\d+(?:\.\d+)+)/)?.[1] ?? null;
}

export function detectTechnologies(headers: Headers | null, setCookies: string[], html: string): Technology[] {
  const found: Technology[] = [];
  const server = headers?.get("server") ?? "";
  const poweredBy = headers?.get("x-powered-by") ?? "";
  const cookieNames = setCookies.map((cookie) => cookie.split("=")[0]);

  const serverRules: { pattern: RegExp; name: string }[] = [
    { pattern: /nginx/i, name: "Nginx" },
    { pattern: /apache/i, name: "Apache" },
    { pattern: /microsoft-iis/i, name: "IIS" },
    { pattern: /litespeed/i, name: "LiteSpeed" },
    { pattern: /caddy/i, name: "Caddy" },
    { pattern: /cloudflare/i, name: "Cloudflare" },
  ];
  for (const rule of serverRules) {
    if (rule.pattern.test(server)) {
      addTechnology(found, {
        name: rule.name,
        category: "Web Server",
        version: versionFrom(server),
        evidence: `Server header: "${server}"`,
      });
    }
  }

  if (/php/i.test(poweredBy) || cookieNames.includes("PHPSESSID")) {
    addTechnology(found, {
      name: "PHP",
      category: "Language",
      version: versionFrom(poweredBy),
      evidence: poweredBy ? `X-Powered-By: "${poweredBy}"` : "PHPSESSID session cookie",
    });
  }
  if (/asp\.net/i.test(poweredBy) || cookieNames.includes("ASP.NET_SessionId")) {
    addTechnology(found, {
      name: "ASP.NET",
      category: "Framework",
      version: versionFrom(poweredBy),
      evidence: poweredBy ? `X-Powered-By: "${poweredBy}"` : "ASP.NET_SessionId cookie",
    });
  }
  if (cookieNames.includes("JSESSIONID")) {
    addTechnology(found, { name: "Java", category: "Language", version: null, evidence: "JSESSIONID session cookie" });
  }
  if (/express/i.test(poweredBy)) {
    addTechnology(found, { name: "Express", category: "Framework", version: null, evidence: `X-Powered-By: "${poweredBy}"` });
  }

  const generator = html.match(/<meta[^>]+name=["']generator["'][^>]+content=["']([^"']+)["']/i)?.[1];
  if (generator) {
    const cmsRules: { pattern: RegExp; name: string }[] = [
      { pattern: /wordpress/i, name: "WordPress" },
      { pattern: /drupal/i, name: "Drupal" },
      { pattern: /joomla/i, name: "Joomla" },
      { pattern: /ghost/i, name: "Ghost" },
    ];
    for (const rule of cmsRules) {
      if (rule.pattern.test(generator)) {
        addTechnology(found, {
          name: rule.name,
          category: "CMS",
          version: versionFrom(generator),
          evidence: `Generator meta tag: "${generator}"`,
        });
      }
    }
  }

  if (/\/wp-(content|includes)\//i.test(html)) {
    addTechnology(found, { name: "WordPress", category: "CMS", version: null, evidence: "wp-content or wp-includes asset paths" });
  }
  if (/\/_next\/static\//i.test(html)) {
    addTechnology(found, { name: "Next.js", category: "Framework", version: null, evidence: "/_next/static asset paths" });
  }

  const jqueryMatch = html.match(/jquery[.-](\d+\.\d+\.\d+)(?:\.min)?\.js/i) ?? html.match(/jquery\/(\d+\.\d+\.\d+)\//i);
  if (jqueryMatch) {
    addTechnology(found, {
      name: "jQuery",
      category: "JavaScript Library",
      version: jqueryMatch[1],
      evidence: `Script include referencing jQuery ${jqueryMatch[1]}`,
    });
  }

  const bootstrapMatch = html.match(/bootstrap[.@/-](\d+\.\d+\.\d+)/i);
  if (bootstrapMatch) {
    addTechnology(found, {
      name: "Bootstrap",
      category: "JavaScript Library",
      version: bootstrapMatch[1],
      evidence: `Asset reference to Bootstrap ${bootstrapMatch[1]}`,
    });
  }

  return found;
}
