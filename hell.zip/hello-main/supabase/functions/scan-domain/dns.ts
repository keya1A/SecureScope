import type { DnsAnalysis, DnsRecords, DnsSecurity } from "./models.ts";

const DOH_ENDPOINT = "https://cloudflare-dns.com/dns-query";
const TYPE_CODES = { A: 1, NS: 2, CNAME: 5, SOA: 6, MX: 15, TXT: 16, AAAA: 28, DS: 43, CAA: 257 } as const;
const DKIM_SELECTORS = ["default", "google", "selector1", "selector2", "k1", "mail", "dkim", "s1", "s2"];

interface DohAnswer {
  name: string;
  type: number;
  data: string;
}

interface DohResponse {
  Status: number;
  AD?: boolean;
  Answer?: DohAnswer[];
}

async function dohQuery(name: string, type: number, requestDnssec = false): Promise<DohResponse> {
  const params = new URLSearchParams({ name, type: String(type) });
  if (requestDnssec) params.set("do", "1");
  const response = await fetch(`${DOH_ENDPOINT}?${params}`, {
    headers: { accept: "application/dns-json" },
    signal: AbortSignal.timeout(6000),
  });
  if (!response.ok) throw new Error(`DNS-over-HTTPS returned HTTP ${response.status}`);
  const body = (await response.json()) as DohResponse;
  return body;
}

function answersOfType(response: DohResponse, type: number): string[] {
  return (response.Answer ?? [])
    .filter((answer) => answer.type === type)
    .map((answer) => answer.data.replace(/^"|"$/g, "").replace(/" "/g, ""));
}

async function recordsOf(name: string, type: keyof typeof TYPE_CODES): Promise<string[]> {
  try {
    const response = await dohQuery(name, TYPE_CODES[type]);
    return response.Status === 0 ? answersOfType(response, TYPE_CODES[type]) : [];
  } catch {
    return [];
  }
}

function policyOf(record: string | null, key: string): string | null {
  if (!record) return null;
  const match = record.match(new RegExp(`(?:^|;)\\s*${key}=([a-z]+)`, "i"));
  return match ? match[1].toLowerCase() : null;
}

async function dkimSelectorsFound(domain: string): Promise<string[]> {
  const results = await Promise.all(
    DKIM_SELECTORS.map(async (selector) => {
      const txt = await recordsOf(`${selector}._domainkey.${domain}`, "TXT");
      return txt.some((value) => /v=DKIM1|p=/i.test(value)) ? selector : null;
    }),
  );
  return results.filter((selector): selector is string => selector !== null);
}

async function dnssecStatus(domain: string): Promise<DnsSecurity["dnssec"]> {
  try {
    const [ds, signed] = await Promise.all([dohQuery(domain, TYPE_CODES.DS), dohQuery(domain, TYPE_CODES.A, true)]);
    const hasDs = answersOfType(ds, TYPE_CODES.DS).length > 0;
    if (!hasDs) return "unsigned";
    return signed.AD ? "signed-validated" : "signed-unvalidated";
  } catch {
    return "unsigned";
  }
}

export async function analyzeDns(domain: string): Promise<DnsAnalysis> {
  const typeNames = Object.keys(TYPE_CODES).filter((type) => type !== "DS") as (keyof typeof TYPE_CODES)[];
  const entries = await Promise.all(typeNames.map(async (type) => [type, await recordsOf(domain, type)] as const));
  const records = Object.fromEntries(entries) as unknown as DnsRecords;

  const spfRecord = records.TXT.find((value) => value.toLowerCase().startsWith("v=spf1")) ?? null;
  const dmarcRecords = await recordsOf(`_dmarc.${domain}`, "TXT");
  const dmarcRecord = dmarcRecords.find((value) => value.toUpperCase().startsWith("V=DMARC1")) ?? null;
  const selectors = await dkimSelectorsFound(domain);

  const security: DnsSecurity = {
    spf: { present: spfRecord !== null, record: spfRecord, policy: spfRecord?.includes("+all") ? "+all" : spfRecord?.match(/[?~-]all/)?.[0] ?? null },
    dmarc: { present: dmarcRecord !== null, record: dmarcRecord, policy: policyOf(dmarcRecord, "p") },
    dkim: { discovered: selectors.length > 0, selectors },
    dnssec: await dnssecStatus(domain),
  };

  return { records, security };
}
