import type { TlsInfo } from "./models.ts";

interface CrtShEntry {
  issuer_name: string;
  common_name: string;
  name_value: string;
  not_before: string;
  not_after: string;
}

const DAY_MS = 86_400_000;

function parseUtc(value: string): number {
  return Date.parse(/[zZ]|[+-]\d\d:?\d\d$/.test(value) ? value : `${value}Z`);
}

function coversDomain(nameValue: string, domain: string): boolean {
  const names = nameValue.split("\n").map((name) => name.trim().toLowerCase());
  const parent = domain.split(".").slice(1).join(".");
  return names.some((name) => name === domain || (name.startsWith("*.") && name.slice(2) === parent));
}

export async function lookupCertificate(domain: string, chainValid: boolean | null): Promise<TlsInfo> {
  const source = "Certificate Transparency logs (crt.sh)";
  const tlsVersionNote = "The scanner runtime does not expose the negotiated TLS version, so it is not measured.";

  const response = await fetch(`https://crt.sh/?q=${encodeURIComponent(domain)}&output=json`, {
    headers: { accept: "application/json" },
    signal: AbortSignal.timeout(12_000),
  });
  if (!response.ok) throw new Error(`Certificate log service returned HTTP ${response.status}`);

  const entries = (await response.json()) as CrtShEntry[];
  const now = Date.now();
  const candidates = entries
    .filter((entry) => coversDomain(entry.name_value, domain))
    .sort((a, b) => parseUtc(b.not_before) - parseUtc(a.not_before));
  const current = candidates.find((entry) => parseUtc(entry.not_after) > now) ?? candidates[0];

  if (!current) {
    return {
      source,
      found: false,
      subject: null,
      issuer: null,
      validFrom: null,
      validUntil: null,
      daysRemaining: null,
      status: "unknown",
      chainValid,
      tlsVersion: null,
      note: `No certificate for ${domain} was found in public logs. ${tlsVersionNote}`,
    };
  }

  const notAfter = parseUtc(current.not_after);
  const daysRemaining = Math.floor((notAfter - now) / DAY_MS);

  return {
    source,
    found: true,
    subject: current.common_name,
    issuer: current.issuer_name,
    validFrom: new Date(parseUtc(current.not_before)).toISOString(),
    validUntil: new Date(notAfter).toISOString(),
    daysRemaining,
    status: daysRemaining < 0 ? "expired" : daysRemaining < 30 ? "expiring" : "valid",
    chainValid,
    tlsVersion: null,
    note: `Details come from the most recently issued certificate in public logs, which may differ from the one served. ${tlsVersionNote}`,
  };
}
