import { createClient } from "npm:@supabase/supabase-js@2";
import { runScan, ScanRejectedError } from "./pipeline.ts";
import { validateDomain } from "./validate.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const HOURLY_SCAN_LIMIT = 30;

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });
  if (req.method !== "POST") return jsonResponse({ error: "Method not allowed." }, 405);

  try {
    const body = (await req.json().catch(() => null)) as { domain?: unknown; authorized?: unknown } | null;
    if (!body || typeof body.domain !== "string") return jsonResponse({ error: "A domain is required." }, 400);
    if (body.authorized !== true) {
      return jsonResponse({ error: "Confirm that you are authorized to assess this domain." }, 400);
    }

    const validation = validateDomain(body.domain);
    if (!validation.ok) return jsonResponse({ error: validation.reason }, 400);

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const windowStart = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { count, error: countError } = await admin
      .from("scans")
      .select("id", { count: "exact", head: true })
      .gte("created_at", windowStart);
    if (countError) throw countError;
    if ((count ?? 0) >= HOURLY_SCAN_LIMIT) {
      return jsonResponse({ error: `Scan limit reached (${HOURLY_SCAN_LIMIT} per hour). Try again later.` }, 429);
    }

    const result = await runScan(validation.domain);
    const { data, error } = await admin
      .from("scans")
      .insert({
        domain: result.domain,
        status: "completed",
        risk_score: result.risk.score,
        risk_category: result.risk.category,
        result,
        duration_ms: result.durationMs,
        created_at: result.scannedAt,
      })
      .select("id")
      .single();
    if (error) throw error;

    return jsonResponse({ id: data.id, result });
  } catch (error) {
    if (error instanceof ScanRejectedError) return jsonResponse({ error: error.message }, 422);
    console.error("scan-domain failed", error);
    return jsonResponse({ error: "The scan could not be completed. Please try again." }, 500);
  }
});
