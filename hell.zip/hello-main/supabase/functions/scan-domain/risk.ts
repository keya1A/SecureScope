import type { CveHit, Finding, RiskAssessment, RiskCategory, Severity } from "./models.ts";

const SEVERITY_WEIGHT: Record<Severity, number> = {
  Critical: 25,
  High: 12,
  Medium: 5,
  Low: 2,
  Informational: 0,
};

const CONFIDENCE_MULTIPLIER: Record<Finding["confidence"], number> = {
  Confirmed: 1,
  Likely: 0.8,
  Inferred: 0.5,
};

const FINDING_POINTS_MAX = 50;
const CVSS_POINTS_MAX = 25;
const KEV_POINTS_MAX = 25;
const KEV_POINTS_EACH = 12.5;

export function categoryForScore(score: number): RiskCategory {
  if (score >= 75) return "Critical";
  if (score >= 50) return "High";
  if (score >= 25) return "Medium";
  return "Low";
}

export function computeRisk(findings: Finding[], cves: CveHit[]): RiskAssessment {
  const rawFindingPoints = findings.reduce(
    (sum, finding) => sum + SEVERITY_WEIGHT[finding.severity] * CONFIDENCE_MULTIPLIER[finding.confidence],
    0,
  );
  const findingPoints = Math.min(FINDING_POINTS_MAX, rawFindingPoints);

  const maxCvss = cves.reduce((max, cve) => Math.max(max, cve.cvss ?? 0), 0);
  const cvssPoints = Math.min(CVSS_POINTS_MAX, (maxCvss / 10) * CVSS_POINTS_MAX);

  const kevCount = cves.filter((cve) => cve.kev).length;
  const kevPoints = Math.min(KEV_POINTS_MAX, kevCount * KEV_POINTS_EACH);

  const score = Math.round(findingPoints + cvssPoints + kevPoints);
  const category = categoryForScore(score);

  const factors = [
    {
      label: "Security findings (severity x confidence)",
      points: Math.round(findingPoints),
      maxPoints: FINDING_POINTS_MAX,
      detail: `${findings.length} finding(s) contributed ${rawFindingPoints.toFixed(1)} raw points before capping.`,
    },
    {
      label: "Highest CVSS score of matched CVEs",
      points: Math.round(cvssPoints),
      maxPoints: CVSS_POINTS_MAX,
      detail: cves.length ? `Highest CVSS base score is ${maxCvss.toFixed(1)} out of 10.` : "No CVEs matched detected versions.",
    },
    {
      label: "Known exploitation (CISA KEV)",
      points: Math.round(kevPoints),
      maxPoints: KEV_POINTS_MAX,
      detail: kevCount ? `${kevCount} matched CVE(s) are listed as actively exploited.` : "No matched CVE is listed in the KEV catalog.",
    },
  ];

  const summary =
    score === 0
      ? "No weaknesses were detected by the non-invasive checks."
      : `The score of ${score} is driven mainly by ${factors
          .slice()
          .sort((a, b) => b.points - a.points)[0]
          .label.toLowerCase()}.`;

  return { score, category, factors, summary };
}
