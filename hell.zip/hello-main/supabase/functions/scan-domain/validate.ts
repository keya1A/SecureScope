const LABEL_PATTERN = /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/;
const BLOCKED_SUFFIXES = [".localhost", ".local", ".localdomain", ".internal", ".lan", ".home", ".corp", ".test", ".invalid", ".example"];

export type DomainValidation = { ok: true; domain: string } | { ok: false; reason: string };

export function validateDomain(input: string): DomainValidation {
  let host = input.trim().toLowerCase();
  if (host.includes("://")) {
    try {
      host = new URL(host).hostname;
    } catch {
      return { ok: false, reason: "That does not look like a valid web address." };
    }
  }
  host = host.split("/")[0];
  if (host.endsWith(".")) host = host.slice(0, -1);

  if (!host) return { ok: false, reason: "Enter a domain name such as example.com." };
  if (host.length > 253) return { ok: false, reason: "Domain names must be 253 characters or fewer." };
  if (/[:@?#\s]/.test(host)) return { ok: false, reason: "Enter only the domain name, without ports, credentials, or query strings." };

  const labels = host.split(".");
  if (labels.length < 2) return { ok: false, reason: "Include a top-level domain, such as .com or .org." };
  if (!labels.every((label) => LABEL_PATTERN.test(label))) {
    return { ok: false, reason: "The domain contains invalid characters." };
  }
  if (!/^[a-z]{2,63}$/.test(labels[labels.length - 1])) {
    return { ok: false, reason: "IP addresses are not accepted. Enter a domain name." };
  }
  if (BLOCKED_SUFFIXES.some((suffix) => host.endsWith(suffix)) || host === "localhost") {
    return { ok: false, reason: "Local, internal, and reserved names cannot be scanned." };
  }
  return { ok: true, domain: host };
}

export function isPrivateAddress(address: string): boolean {
  if (address.includes(":")) {
    const lower = address.toLowerCase();
    return (
      lower === "::" ||
      lower === "::1" ||
      lower.startsWith("fe80") ||
      lower.startsWith("fc") ||
      lower.startsWith("fd") ||
      lower.startsWith("::ffff:127.") ||
      lower.startsWith("::ffff:10.") ||
      lower.startsWith("::ffff:192.168.")
    );
  }
  const [a, b] = address.split(".").map(Number);
  if (Number.isNaN(a) || Number.isNaN(b)) return true;
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127) ||
    a >= 224
  );
}
